﻿using SewingProduction.Core.Class;
namespace SewingProduction.form.Nadezhda
{
    partial class KnittingProductionPlanning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KnittingProductionPlanning));
            gridControlVyazPlan = new CustomGridControl();
            gridViewVyazPlan = new DevExpress.XtraGrid.Views.Grid.GridView();
            gridColumnVyazPlanPszkmPlanDate = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanKmlNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanSekVyazAll = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanKol = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanZvetTkan = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanSekVyaz = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanNameVyazClass = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanGrup = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanArticul = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanDateCdPlan = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanNameSbit = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanDateZap = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanNomZad = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnVyazPlanSyncSelection = new DevExpress.XtraGrid.Columns.GridColumn();
            repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            gridColumnVyazPlanNn = new DevExpress.XtraGrid.Columns.GridColumn();
            repositoryItemCheckedComboBoxEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckedComboBoxEdit();
            repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            pictureBoxEskiz = new System.Windows.Forms.PictureBox();
            tablePanel1 = new DevExpress.Utils.Layout.TablePanel();
            tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            comboBoxKnitMachineList = new CustomComboBox();
            customLabel2 = new CustomLabel();
            tablePanel3 = new DevExpress.Utils.Layout.TablePanel();
            customLabel4 = new CustomLabel();
            gridControlArtPrKnitMachineViewPr2 = new CustomGridControl();
            gridView5 = new DevExpress.XtraGrid.Views.Grid.GridView();
            gridColumnArtPrKnitMachineViewPr2KmlNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            gridControlArtPrKnitMachineViewRecom2 = new CustomGridControl();
            gridView6 = new DevExpress.XtraGrid.Views.Grid.GridView();
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnArtPrKnitMachineViewRecom2KmlNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth = new DevExpress.XtraGrid.Columns.GridColumn();
            tablePanel2 = new DevExpress.Utils.Layout.TablePanel();
            customLabel3 = new CustomLabel();
            gridControlArtPrKnitMachineViewPr1 = new CustomGridControl();
            gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            gridColumnArtPrKnitMachineViewPr1KmlNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            gridControlArtPrKnitMachineViewRecom1 = new CustomGridControl();
            gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnArtPrKnitMachineViewRecom1KmlNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth = new DevExpress.XtraGrid.Columns.GridColumn();
            simpleButtonSaveVyaz = new CustomSimpleButton();
            simpleButtonClearKnitMachine = new CustomSimpleButton();
            gridControlPlanSezonZadanyRazmKol = new CustomGridControl();
            gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            gridColumnPlanSezonZadanyRazmKolKol = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnPlanSezonZadanyRazmKolRazm = new DevExpress.XtraGrid.Columns.GridColumn();
            simpleButtonSetKnitMachine = new CustomSimpleButton();
            gridControlArtPrFioProgr = new CustomGridControl();
            gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnArtPrFioProgrRazm = new DevExpress.XtraGrid.Columns.GridColumn();
            gridColumnArtPrFioProgrArticul = new DevExpress.XtraGrid.Columns.GridColumn();
            tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            customTextBox1 = new CustomTextBox();
            customLabel1 = new CustomLabel();
            gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            simpleSeparator1 = new DevExpress.XtraLayout.SimpleSeparator();
            ((System.ComponentModel.ISupportInitialize)gridControlVyazPlan).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridViewVyazPlan).BeginInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemCheckEdit1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemCheckedComboBoxEdit1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemLookUpEdit1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxEskiz).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tablePanel1).BeginInit();
            tablePanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)tablePanel3).BeginInit();
            tablePanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrKnitMachineViewPr2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrKnitMachineViewRecom2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tablePanel2).BeginInit();
            tablePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrKnitMachineViewPr1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrKnitMachineViewRecom1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridControlPlanSezonZadanyRazmKol).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrFioProgr).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)simpleSeparator1).BeginInit();
            SuspendLayout();
            // 
            // gridControlVyazPlan
            // 
            tablePanel1.SetColumn(gridControlVyazPlan, 0);
            tablePanel1.SetColumnSpan(gridControlVyazPlan, 11);
            gridControlVyazPlan.Dock = System.Windows.Forms.DockStyle.Fill;
            gridControlVyazPlan.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlVyazPlan.Font = new System.Drawing.Font("Arial", 10F);
            gridControlVyazPlan.Location = new System.Drawing.Point(15, 13);
            gridControlVyazPlan.MainView = gridViewVyazPlan;
            gridControlVyazPlan.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlVyazPlan.Name = "gridControlVyazPlan";
            gridControlVyazPlan.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] { repositoryItemCheckEdit1, repositoryItemCheckedComboBoxEdit1, repositoryItemLookUpEdit1 });
            tablePanel1.SetRow(gridControlVyazPlan, 0);
            gridControlVyazPlan.Size = new System.Drawing.Size(1757, 416);
            gridControlVyazPlan.TabIndex = 0;
            gridControlVyazPlan.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridViewVyazPlan });
            // 
            // gridViewVyazPlan
            // 
            gridViewVyazPlan.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(255, 223, 196);
            gridViewVyazPlan.Appearance.EvenRow.Options.UseBackColor = true;
            gridViewVyazPlan.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { gridColumnVyazPlanPszkmPlanDate, gridColumnVyazPlanKmlNumber, gridColumnVyazPlanSekVyazAll, gridColumnVyazPlanKol, gridColumnVyazPlanZvetTkan, gridColumnVyazPlanSekVyaz, gridColumnVyazPlanNameVyazClass, gridColumnVyazPlanGrup, gridColumnVyazPlanArticul, gridColumnVyazPlanDateCdPlan, gridColumnVyazPlanNameSbit, gridColumnVyazPlanDateZap, gridColumnVyazPlanNomZad, gridColumnVyazPlanSyncSelection, gridColumnVyazPlanNn });
            gridViewVyazPlan.CustomizationFormBounds = new System.Drawing.Rectangle(1597, 675, 308, 314);
            gridViewVyazPlan.DetailHeight = 404;
            gridViewVyazPlan.GridControl = gridControlVyazPlan;
            gridViewVyazPlan.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] { new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SekVyazAll", gridColumnVyazPlanSekVyazAll, "(Итого ч/час: {0:0.##})") });
            gridViewVyazPlan.Name = "gridViewVyazPlan";
            gridViewVyazPlan.OptionsEditForm.PopupEditFormWidth = 933;
            gridViewVyazPlan.OptionsSelection.CheckBoxSelectorField = "SyncSelection";
            gridViewVyazPlan.OptionsSelection.MultiSelect = true;
            gridViewVyazPlan.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            gridViewVyazPlan.OptionsSelection.ShowCheckBoxSelectorInColumnHeader = DevExpress.Utils.DefaultBoolean.False;
            gridViewVyazPlan.OptionsSelection.ShowCheckBoxSelectorInGroupRow = DevExpress.Utils.DefaultBoolean.False;
            gridViewVyazPlan.OptionsView.EnableAppearanceEvenRow = true;
            gridViewVyazPlan.OptionsView.ShowFooter = true;
            gridViewVyazPlan.OptionsView.ShowIndicator = false;
            gridViewVyazPlan.FocusedRowChanged += gridViewVyazPlan_FocusedRowChanged;
            // 
            // gridColumnVyazPlanPszkmPlanDate
            // 
            gridColumnVyazPlanPszkmPlanDate.Caption = "План. дата запуска в произ.";
            gridColumnVyazPlanPszkmPlanDate.MinWidth = 23;
            gridColumnVyazPlanPszkmPlanDate.Name = "gridColumnVyazPlanPszkmPlanDate";
            gridColumnVyazPlanPszkmPlanDate.Visible = true;
            gridColumnVyazPlanPszkmPlanDate.VisibleIndex = 15;
            gridColumnVyazPlanPszkmPlanDate.Width = 87;
            // 
            // gridColumnVyazPlanKmlNumber
            // 
            gridColumnVyazPlanKmlNumber.Caption = "В/М";
            gridColumnVyazPlanKmlNumber.MinWidth = 23;
            gridColumnVyazPlanKmlNumber.Name = "gridColumnVyazPlanKmlNumber";
            gridColumnVyazPlanKmlNumber.Visible = true;
            gridColumnVyazPlanKmlNumber.VisibleIndex = 14;
            gridColumnVyazPlanKmlNumber.Width = 87;
            // 
            // gridColumnVyazPlanSekVyazAll
            // 
            gridColumnVyazPlanSekVyazAll.Caption = "Время вяз. задания, час";
            gridColumnVyazPlanSekVyazAll.MinWidth = 23;
            gridColumnVyazPlanSekVyazAll.Name = "gridColumnVyazPlanSekVyazAll";
            gridColumnVyazPlanSekVyazAll.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] { new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, DevExpress.Data.SummaryMode.Selection, "SekVyazAll", "(Итого: {0:0.##})") });
            gridColumnVyazPlanSekVyazAll.Visible = true;
            gridColumnVyazPlanSekVyazAll.VisibleIndex = 12;
            gridColumnVyazPlanSekVyazAll.Width = 87;
            // 
            // gridColumnVyazPlanKol
            // 
            gridColumnVyazPlanKol.Caption = "Количество";
            gridColumnVyazPlanKol.MinWidth = 23;
            gridColumnVyazPlanKol.Name = "gridColumnVyazPlanKol";
            gridColumnVyazPlanKol.Visible = true;
            gridColumnVyazPlanKol.VisibleIndex = 11;
            gridColumnVyazPlanKol.Width = 87;
            // 
            // gridColumnVyazPlanZvetTkan
            // 
            gridColumnVyazPlanZvetTkan.Caption = "Цвет по заданию (матрица)";
            gridColumnVyazPlanZvetTkan.MinWidth = 23;
            gridColumnVyazPlanZvetTkan.Name = "gridColumnVyazPlanZvetTkan";
            gridColumnVyazPlanZvetTkan.Visible = true;
            gridColumnVyazPlanZvetTkan.VisibleIndex = 10;
            gridColumnVyazPlanZvetTkan.Width = 87;
            // 
            // gridColumnVyazPlanSekVyaz
            // 
            gridColumnVyazPlanSekVyaz.Caption = "Время вяз. 1 изделия";
            gridColumnVyazPlanSekVyaz.MinWidth = 23;
            gridColumnVyazPlanSekVyaz.Name = "gridColumnVyazPlanSekVyaz";
            gridColumnVyazPlanSekVyaz.Visible = true;
            gridColumnVyazPlanSekVyaz.VisibleIndex = 9;
            gridColumnVyazPlanSekVyaz.Width = 87;
            // 
            // gridColumnVyazPlanNameVyazClass
            // 
            gridColumnVyazPlanNameVyazClass.Caption = "Класс вязания";
            gridColumnVyazPlanNameVyazClass.MinWidth = 23;
            gridColumnVyazPlanNameVyazClass.Name = "gridColumnVyazPlanNameVyazClass";
            gridColumnVyazPlanNameVyazClass.Visible = true;
            gridColumnVyazPlanNameVyazClass.VisibleIndex = 8;
            gridColumnVyazPlanNameVyazClass.Width = 87;
            // 
            // gridColumnVyazPlanGrup
            // 
            gridColumnVyazPlanGrup.Caption = "Группа";
            gridColumnVyazPlanGrup.MinWidth = 23;
            gridColumnVyazPlanGrup.Name = "gridColumnVyazPlanGrup";
            gridColumnVyazPlanGrup.Visible = true;
            gridColumnVyazPlanGrup.VisibleIndex = 7;
            gridColumnVyazPlanGrup.Width = 87;
            // 
            // gridColumnVyazPlanArticul
            // 
            gridColumnVyazPlanArticul.Caption = "Артикул";
            gridColumnVyazPlanArticul.MinWidth = 23;
            gridColumnVyazPlanArticul.Name = "gridColumnVyazPlanArticul";
            gridColumnVyazPlanArticul.Visible = true;
            gridColumnVyazPlanArticul.VisibleIndex = 6;
            gridColumnVyazPlanArticul.Width = 87;
            // 
            // gridColumnVyazPlanDateCdPlan
            // 
            gridColumnVyazPlanDateCdPlan.Caption = "Дата сдачи";
            gridColumnVyazPlanDateCdPlan.MinWidth = 23;
            gridColumnVyazPlanDateCdPlan.Name = "gridColumnVyazPlanDateCdPlan";
            gridColumnVyazPlanDateCdPlan.Visible = true;
            gridColumnVyazPlanDateCdPlan.VisibleIndex = 5;
            gridColumnVyazPlanDateCdPlan.Width = 87;
            // 
            // gridColumnVyazPlanNameSbit
            // 
            gridColumnVyazPlanNameSbit.Caption = "Канал сбыта";
            gridColumnVyazPlanNameSbit.MinWidth = 23;
            gridColumnVyazPlanNameSbit.Name = "gridColumnVyazPlanNameSbit";
            gridColumnVyazPlanNameSbit.Visible = true;
            gridColumnVyazPlanNameSbit.VisibleIndex = 4;
            gridColumnVyazPlanNameSbit.Width = 87;
            // 
            // gridColumnVyazPlanDateZap
            // 
            gridColumnVyazPlanDateZap.Caption = "Дата запуска";
            gridColumnVyazPlanDateZap.MinWidth = 23;
            gridColumnVyazPlanDateZap.Name = "gridColumnVyazPlanDateZap";
            gridColumnVyazPlanDateZap.Visible = true;
            gridColumnVyazPlanDateZap.VisibleIndex = 3;
            gridColumnVyazPlanDateZap.Width = 87;
            // 
            // gridColumnVyazPlanNomZad
            // 
            gridColumnVyazPlanNomZad.Caption = "№ задания";
            gridColumnVyazPlanNomZad.MinWidth = 23;
            gridColumnVyazPlanNomZad.Name = "gridColumnVyazPlanNomZad";
            gridColumnVyazPlanNomZad.Visible = true;
            gridColumnVyazPlanNomZad.VisibleIndex = 2;
            gridColumnVyazPlanNomZad.Width = 87;
            // 
            // gridColumnVyazPlanSyncSelection
            // 
            gridColumnVyazPlanSyncSelection.Caption = "V";
            gridColumnVyazPlanSyncSelection.ColumnEdit = repositoryItemCheckEdit1;
            gridColumnVyazPlanSyncSelection.FieldName = "gridColumnVyazPlanSyncSelection";
            gridColumnVyazPlanSyncSelection.MinWidth = 23;
            gridColumnVyazPlanSyncSelection.Name = "gridColumnVyazPlanSyncSelection";
            gridColumnVyazPlanSyncSelection.UnboundDataType = typeof(bool);
            gridColumnVyazPlanSyncSelection.Visible = true;
            gridColumnVyazPlanSyncSelection.VisibleIndex = 13;
            gridColumnVyazPlanSyncSelection.Width = 72;
            // 
            // repositoryItemCheckEdit1
            // 
            repositoryItemCheckEdit1.AutoHeight = false;
            repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            // 
            // gridColumnVyazPlanNn
            // 
            gridColumnVyazPlanNn.Caption = "Код матрицы";
            gridColumnVyazPlanNn.MinWidth = 23;
            gridColumnVyazPlanNn.Name = "gridColumnVyazPlanNn";
            gridColumnVyazPlanNn.Visible = true;
            gridColumnVyazPlanNn.VisibleIndex = 1;
            gridColumnVyazPlanNn.Width = 87;
            // 
            // repositoryItemCheckedComboBoxEdit1
            // 
            repositoryItemCheckedComboBoxEdit1.AutoHeight = false;
            repositoryItemCheckedComboBoxEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            repositoryItemCheckedComboBoxEdit1.Name = "repositoryItemCheckedComboBoxEdit1";
            // 
            // repositoryItemLookUpEdit1
            // 
            repositoryItemLookUpEdit1.AutoHeight = false;
            repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            // 
            // pictureBoxEskiz
            // 
            pictureBoxEskiz.Dock = System.Windows.Forms.DockStyle.Fill;
            pictureBoxEskiz.Location = new System.Drawing.Point(15, 527);
            pictureBoxEskiz.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            pictureBoxEskiz.Name = "pictureBoxEskiz";
            pictureBoxEskiz.Size = new System.Drawing.Size(305, 231);
            pictureBoxEskiz.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBoxEskiz.TabIndex = 26;
            pictureBoxEskiz.TabStop = false;
            // 
            // tablePanel1
            // 
            tablePanel1.Columns.AddRange(new DevExpress.Utils.Layout.TablePanelColumn[] { new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 293F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 45.54004F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 240F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 35F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 410F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 50F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 410F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 50F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 107F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 120F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 150F) });
            tablePanel1.Controls.Add(tableLayoutPanel2);
            tablePanel1.Controls.Add(tablePanel3);
            tablePanel1.Controls.Add(tablePanel2);
            tablePanel1.Controls.Add(simpleButtonSaveVyaz);
            tablePanel1.Controls.Add(simpleButtonClearKnitMachine);
            tablePanel1.Controls.Add(gridControlPlanSezonZadanyRazmKol);
            tablePanel1.Controls.Add(simpleButtonSetKnitMachine);
            tablePanel1.Controls.Add(gridControlArtPrFioProgr);
            tablePanel1.Controls.Add(tableLayoutPanel1);
            tablePanel1.Controls.Add(gridControlVyazPlan);
            tablePanel1.Controls.Add(pictureBoxEskiz);
            tablePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            tablePanel1.Location = new System.Drawing.Point(0, 0);
            tablePanel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            tablePanel1.Name = "tablePanel1";
            tablePanel1.Rows.AddRange(new DevExpress.Utils.Layout.TablePanelRow[] { new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 422F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 34F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 26F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 34F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 26F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 34F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 203F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Separator, 26F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 200F) });
            tablePanel1.Size = new System.Drawing.Size(1787, 966);
            tablePanel1.TabIndex = 27;
            tablePanel1.UseSkinIndents = true;
            // 
            // tableLayoutPanel2
            // 
            tablePanel1.SetColumn(tableLayoutPanel2, 6);
            tableLayoutPanel2.ColumnCount = 2;
            tablePanel1.SetColumnSpan(tableLayoutPanel2, 4);
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.2489243F));
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.7510738F));
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            tableLayoutPanel2.Controls.Add(comboBoxKnitMachineList, 1, 0);
            tableLayoutPanel2.Controls.Add(customLabel2, 0, 0);
            tableLayoutPanel2.Location = new System.Drawing.Point(1016, 434);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tablePanel1.SetRow(tableLayoutPanel2, 1);
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new System.Drawing.Size(466, 30);
            tableLayoutPanel2.TabIndex = 38;
            // 
            // comboBoxKnitMachineList
            // 
            comboBoxKnitMachineList.BackColor = System.Drawing.Color.FromArgb(250, 240, 230);
            comboBoxKnitMachineList.Dock = System.Windows.Forms.DockStyle.Top;
            comboBoxKnitMachineList.Font = new System.Drawing.Font("Arial", 10F);
            comboBoxKnitMachineList.ForeColor = System.Drawing.Color.FromArgb(105, 75, 45);
            comboBoxKnitMachineList.FormattingEnabled = true;
            comboBoxKnitMachineList.Location = new System.Drawing.Point(350, 3);
            comboBoxKnitMachineList.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            comboBoxKnitMachineList.Name = "comboBoxKnitMachineList";
            comboBoxKnitMachineList.Size = new System.Drawing.Size(112, 24);
            comboBoxKnitMachineList.TabIndex = 35;
            // 
            // customLabel2
            // 
            customLabel2.AutoSize = true;
            customLabel2.Dock = System.Windows.Forms.DockStyle.Right;
            customLabel2.Font = new System.Drawing.Font("Arial", 10F);
            customLabel2.ForeColor = System.Drawing.Color.FromArgb(139, 69, 19);
            customLabel2.Location = new System.Drawing.Point(255, 0);
            customLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            customLabel2.Name = "customLabel2";
            customLabel2.Size = new System.Drawing.Size(87, 30);
            customLabel2.TabIndex = 36;
            customLabel2.Text = "Вяз машина";
            customLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tablePanel3
            // 
            tablePanel3.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            tablePanel1.SetColumn(tablePanel3, 6);
            tablePanel3.Columns.AddRange(new DevExpress.Utils.Layout.TablePanelColumn[] { new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 100F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 40.15F) });
            tablePanel3.Controls.Add(customLabel4);
            tablePanel3.Controls.Add(gridControlArtPrKnitMachineViewPr2);
            tablePanel3.Controls.Add(gridControlArtPrKnitMachineViewRecom2);
            tablePanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            tablePanel3.Location = new System.Drawing.Point(1018, 481);
            tablePanel3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            tablePanel3.Name = "tablePanel3";
            tablePanel1.SetRow(tablePanel3, 3);
            tablePanel3.Rows.AddRange(new DevExpress.Utils.Layout.TablePanelRow[] { new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 26F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 26F) });
            tablePanel1.SetRowSpan(tablePanel3, 4);
            tablePanel3.Size = new System.Drawing.Size(402, 277);
            tablePanel3.TabIndex = 0;
            tablePanel3.UseSkinIndents = true;
            // 
            // customLabel4
            // 
            customLabel4.AutoSize = true;
            tablePanel3.SetColumn(customLabel4, 0);
            tablePanel3.SetColumnSpan(customLabel4, 2);
            customLabel4.Dock = System.Windows.Forms.DockStyle.Fill;
            customLabel4.Font = new System.Drawing.Font("Arial", 10F);
            customLabel4.ForeColor = System.Drawing.Color.FromArgb(139, 69, 19);
            customLabel4.Location = new System.Drawing.Point(15, 10);
            customLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            customLabel4.Name = "customLabel4";
            tablePanel3.SetRow(customLabel4, 0);
            customLabel4.Size = new System.Drawing.Size(372, 26);
            customLabel4.TabIndex = 39;
            customLabel4.Text = "Вспомогательная В/М";
            // 
            // gridControlArtPrKnitMachineViewPr2
            // 
            tablePanel3.SetColumn(gridControlArtPrKnitMachineViewPr2, 0);
            gridControlArtPrKnitMachineViewPr2.Dock = System.Windows.Forms.DockStyle.Fill;
            gridControlArtPrKnitMachineViewPr2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrKnitMachineViewPr2.Font = new System.Drawing.Font("Arial", 10F);
            gridControlArtPrKnitMachineViewPr2.Location = new System.Drawing.Point(15, 39);
            gridControlArtPrKnitMachineViewPr2.MainView = gridView5;
            gridControlArtPrKnitMachineViewPr2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrKnitMachineViewPr2.Name = "gridControlArtPrKnitMachineViewPr2";
            tablePanel3.SetRow(gridControlArtPrKnitMachineViewPr2, 1);
            gridControlArtPrKnitMachineViewPr2.Size = new System.Drawing.Size(92, 224);
            gridControlArtPrKnitMachineViewPr2.TabIndex = 37;
            gridControlArtPrKnitMachineViewPr2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView5 });
            // 
            // gridView5
            // 
            gridView5.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(255, 235, 205);
            gridView5.Appearance.EvenRow.Options.UseBackColor = true;
            gridView5.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { gridColumnArtPrKnitMachineViewPr2KmlNumber });
            gridView5.DetailHeight = 404;
            gridView5.GridControl = gridControlArtPrKnitMachineViewPr2;
            gridView5.Name = "gridView5";
            gridView5.OptionsEditForm.PopupEditFormWidth = 933;
            gridView5.OptionsView.EnableAppearanceEvenRow = true;
            gridView5.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumnArtPrKnitMachineViewPr2KmlNumber
            // 
            gridColumnArtPrKnitMachineViewPr2KmlNumber.Caption = "в/м ПР вспомог.";
            gridColumnArtPrKnitMachineViewPr2KmlNumber.MinWidth = 23;
            gridColumnArtPrKnitMachineViewPr2KmlNumber.Name = "gridColumnArtPrKnitMachineViewPr2KmlNumber";
            gridColumnArtPrKnitMachineViewPr2KmlNumber.Visible = true;
            gridColumnArtPrKnitMachineViewPr2KmlNumber.VisibleIndex = 0;
            gridColumnArtPrKnitMachineViewPr2KmlNumber.Width = 87;
            // 
            // gridControlArtPrKnitMachineViewRecom2
            // 
            tablePanel3.SetColumn(gridControlArtPrKnitMachineViewRecom2, 1);
            gridControlArtPrKnitMachineViewRecom2.Dock = System.Windows.Forms.DockStyle.Fill;
            gridControlArtPrKnitMachineViewRecom2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrKnitMachineViewRecom2.Font = new System.Drawing.Font("Arial", 10F);
            gridControlArtPrKnitMachineViewRecom2.Location = new System.Drawing.Point(115, 39);
            gridControlArtPrKnitMachineViewRecom2.MainView = gridView6;
            gridControlArtPrKnitMachineViewRecom2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrKnitMachineViewRecom2.Name = "gridControlArtPrKnitMachineViewRecom2";
            tablePanel3.SetRow(gridControlArtPrKnitMachineViewRecom2, 1);
            gridControlArtPrKnitMachineViewRecom2.Size = new System.Drawing.Size(272, 224);
            gridControlArtPrKnitMachineViewRecom2.TabIndex = 38;
            gridControlArtPrKnitMachineViewRecom2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView6 });
            // 
            // gridView6
            // 
            gridView6.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(255, 235, 205);
            gridView6.Appearance.EvenRow.Options.UseBackColor = true;
            gridView6.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth, gridColumnArtPrKnitMachineViewRecom2KmlNumber, gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth });
            gridView6.DetailHeight = 404;
            gridView6.GridControl = gridControlArtPrKnitMachineViewRecom2;
            gridView6.Name = "gridView6";
            gridView6.OptionsEditForm.PopupEditFormWidth = 933;
            gridView6.OptionsView.EnableAppearanceEvenRow = true;
            gridView6.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth
            // 
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth.Caption = "своб. часы тек. месяц";
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth.MinWidth = 23;
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth.Name = "gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth";
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth.Visible = true;
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth.VisibleIndex = 1;
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth.Width = 81;
            // 
            // gridColumnArtPrKnitMachineViewRecom2KmlNumber
            // 
            gridColumnArtPrKnitMachineViewRecom2KmlNumber.Caption = "в/м реком.";
            gridColumnArtPrKnitMachineViewRecom2KmlNumber.MinWidth = 23;
            gridColumnArtPrKnitMachineViewRecom2KmlNumber.Name = "gridColumnArtPrKnitMachineViewRecom2KmlNumber";
            gridColumnArtPrKnitMachineViewRecom2KmlNumber.Visible = true;
            gridColumnArtPrKnitMachineViewRecom2KmlNumber.VisibleIndex = 0;
            gridColumnArtPrKnitMachineViewRecom2KmlNumber.Width = 80;
            // 
            // gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth
            // 
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth.Caption = "своб. часы след. месяц";
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth.MinWidth = 23;
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth.Name = "gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth";
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth.Visible = true;
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth.VisibleIndex = 2;
            gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth.Width = 86;
            // 
            // tablePanel2
            // 
            tablePanel2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            tablePanel1.SetColumn(tablePanel2, 4);
            tablePanel2.Columns.AddRange(new DevExpress.Utils.Layout.TablePanelColumn[] { new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 100F), new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 40.15F) });
            tablePanel2.Controls.Add(customLabel3);
            tablePanel2.Controls.Add(gridControlArtPrKnitMachineViewPr1);
            tablePanel2.Controls.Add(gridControlArtPrKnitMachineViewRecom1);
            tablePanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            tablePanel2.Location = new System.Drawing.Point(588, 481);
            tablePanel2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            tablePanel2.Name = "tablePanel2";
            tablePanel1.SetRow(tablePanel2, 3);
            tablePanel2.Rows.AddRange(new DevExpress.Utils.Layout.TablePanelRow[] { new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 26F), new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 26F) });
            tablePanel1.SetRowSpan(tablePanel2, 4);
            tablePanel2.Size = new System.Drawing.Size(402, 277);
            tablePanel2.TabIndex = 0;
            tablePanel2.UseSkinIndents = true;
            // 
            // customLabel3
            // 
            customLabel3.AutoSize = true;
            tablePanel2.SetColumn(customLabel3, 0);
            tablePanel2.SetColumnSpan(customLabel3, 2);
            customLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            customLabel3.Font = new System.Drawing.Font("Arial", 10F);
            customLabel3.ForeColor = System.Drawing.Color.FromArgb(139, 69, 19);
            customLabel3.Location = new System.Drawing.Point(15, 10);
            customLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            customLabel3.Name = "customLabel3";
            tablePanel2.SetRow(customLabel3, 0);
            customLabel3.Size = new System.Drawing.Size(372, 26);
            customLabel3.TabIndex = 35;
            customLabel3.Text = "Основная В/М";
            // 
            // gridControlArtPrKnitMachineViewPr1
            // 
            tablePanel2.SetColumn(gridControlArtPrKnitMachineViewPr1, 0);
            gridControlArtPrKnitMachineViewPr1.Dock = System.Windows.Forms.DockStyle.Fill;
            gridControlArtPrKnitMachineViewPr1.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrKnitMachineViewPr1.Font = new System.Drawing.Font("Arial", 10F);
            gridControlArtPrKnitMachineViewPr1.Location = new System.Drawing.Point(15, 39);
            gridControlArtPrKnitMachineViewPr1.MainView = gridView3;
            gridControlArtPrKnitMachineViewPr1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrKnitMachineViewPr1.Name = "gridControlArtPrKnitMachineViewPr1";
            tablePanel2.SetRow(gridControlArtPrKnitMachineViewPr1, 1);
            gridControlArtPrKnitMachineViewPr1.Size = new System.Drawing.Size(92, 224);
            gridControlArtPrKnitMachineViewPr1.TabIndex = 33;
            gridControlArtPrKnitMachineViewPr1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView3 });
            // 
            // gridView3
            // 
            gridView3.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(255, 235, 205);
            gridView3.Appearance.EvenRow.Options.UseBackColor = true;
            gridView3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { gridColumnArtPrKnitMachineViewPr1KmlNumber });
            gridView3.DetailHeight = 404;
            gridView3.GridControl = gridControlArtPrKnitMachineViewPr1;
            gridView3.Name = "gridView3";
            gridView3.OptionsEditForm.PopupEditFormWidth = 933;
            gridView3.OptionsView.EnableAppearanceEvenRow = true;
            gridView3.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumnArtPrKnitMachineViewPr1KmlNumber
            // 
            gridColumnArtPrKnitMachineViewPr1KmlNumber.Caption = "в/м ПР основн.";
            gridColumnArtPrKnitMachineViewPr1KmlNumber.MinWidth = 23;
            gridColumnArtPrKnitMachineViewPr1KmlNumber.Name = "gridColumnArtPrKnitMachineViewPr1KmlNumber";
            gridColumnArtPrKnitMachineViewPr1KmlNumber.Visible = true;
            gridColumnArtPrKnitMachineViewPr1KmlNumber.VisibleIndex = 0;
            gridColumnArtPrKnitMachineViewPr1KmlNumber.Width = 87;
            // 
            // gridControlArtPrKnitMachineViewRecom1
            // 
            tablePanel2.SetColumn(gridControlArtPrKnitMachineViewRecom1, 1);
            gridControlArtPrKnitMachineViewRecom1.Dock = System.Windows.Forms.DockStyle.Fill;
            gridControlArtPrKnitMachineViewRecom1.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrKnitMachineViewRecom1.Font = new System.Drawing.Font("Arial", 10F);
            gridControlArtPrKnitMachineViewRecom1.Location = new System.Drawing.Point(115, 39);
            gridControlArtPrKnitMachineViewRecom1.MainView = gridView4;
            gridControlArtPrKnitMachineViewRecom1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrKnitMachineViewRecom1.Name = "gridControlArtPrKnitMachineViewRecom1";
            tablePanel2.SetRow(gridControlArtPrKnitMachineViewRecom1, 1);
            gridControlArtPrKnitMachineViewRecom1.Size = new System.Drawing.Size(272, 224);
            gridControlArtPrKnitMachineViewRecom1.TabIndex = 34;
            gridControlArtPrKnitMachineViewRecom1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView4 });
            gridControlArtPrKnitMachineViewRecom1.Click += gridControlArtPrKnitMachineViewRecom1_Click;
            // 
            // gridView4
            // 
            gridView4.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(255, 235, 205);
            gridView4.Appearance.EvenRow.Options.UseBackColor = true;
            gridView4.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth, gridColumnArtPrKnitMachineViewRecom1KmlNumber, gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth });
            gridView4.DetailHeight = 404;
            gridView4.GridControl = gridControlArtPrKnitMachineViewRecom1;
            gridView4.Name = "gridView4";
            gridView4.OptionsEditForm.PopupEditFormWidth = 933;
            gridView4.OptionsView.EnableAppearanceEvenRow = true;
            gridView4.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth
            // 
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth.Caption = "своб. часы тек. месяц";
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth.MinWidth = 23;
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth.Name = "gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth";
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth.Visible = true;
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth.VisibleIndex = 1;
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth.Width = 81;
            // 
            // gridColumnArtPrKnitMachineViewRecom1KmlNumber
            // 
            gridColumnArtPrKnitMachineViewRecom1KmlNumber.Caption = "в/м реком.";
            gridColumnArtPrKnitMachineViewRecom1KmlNumber.MinWidth = 23;
            gridColumnArtPrKnitMachineViewRecom1KmlNumber.Name = "gridColumnArtPrKnitMachineViewRecom1KmlNumber";
            gridColumnArtPrKnitMachineViewRecom1KmlNumber.Visible = true;
            gridColumnArtPrKnitMachineViewRecom1KmlNumber.VisibleIndex = 0;
            gridColumnArtPrKnitMachineViewRecom1KmlNumber.Width = 80;
            // 
            // gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth
            // 
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth.Caption = "своб. часы след. месяц";
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth.MinWidth = 23;
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth.Name = "gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth";
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth.Visible = true;
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth.VisibleIndex = 2;
            gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth.Width = 86;
            // 
            // simpleButtonSaveVyaz
            // 
            simpleButtonSaveVyaz.Appearance.BackColor = System.Drawing.Color.FromArgb(255, 223, 196);
            simpleButtonSaveVyaz.Appearance.Font = new System.Drawing.Font("Arial", 10F);
            simpleButtonSaveVyaz.Appearance.ForeColor = System.Drawing.Color.FromArgb(139, 69, 19);
            simpleButtonSaveVyaz.Appearance.Options.UseBackColor = true;
            simpleButtonSaveVyaz.Appearance.Options.UseFont = true;
            simpleButtonSaveVyaz.Appearance.Options.UseForeColor = true;
            simpleButtonSaveVyaz.AppearanceDisabled.BackColor = System.Drawing.Color.Green;
            simpleButtonSaveVyaz.AppearanceDisabled.ForeColor = System.Drawing.Color.GreenYellow;
            simpleButtonSaveVyaz.AppearanceDisabled.Options.UseBackColor = true;
            simpleButtonSaveVyaz.AppearanceDisabled.Options.UseForeColor = true;
            tablePanel1.SetColumn(simpleButtonSaveVyaz, 10);
            simpleButtonSaveVyaz.Dock = System.Windows.Forms.DockStyle.Top;
            simpleButtonSaveVyaz.Enabled = false;
            simpleButtonSaveVyaz.ImageOptions.Image = (System.Drawing.Image)resources.GetObject("simpleButtonSaveVyaz.ImageOptions.Image");
            simpleButtonSaveVyaz.Location = new System.Drawing.Point(1488, 527);
            simpleButtonSaveVyaz.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            simpleButtonSaveVyaz.Name = "simpleButtonSaveVyaz";
            tablePanel1.SetRow(simpleButtonSaveVyaz, 5);
            simpleButtonSaveVyaz.Size = new System.Drawing.Size(284, 24);
            simpleButtonSaveVyaz.TabIndex = 31;
            simpleButtonSaveVyaz.Text = "Сохранить";
            simpleButtonSaveVyaz.Click += simpleButtonSaveVyaz_Click;
            // 
            // simpleButtonClearKnitMachine
            // 
            simpleButtonClearKnitMachine.Appearance.BackColor = System.Drawing.Color.FromArgb(180, 220, 240);
            simpleButtonClearKnitMachine.Appearance.Font = new System.Drawing.Font("Arial", 10F);
            simpleButtonClearKnitMachine.Appearance.ForeColor = System.Drawing.Color.FromArgb(20, 70, 100);
            simpleButtonClearKnitMachine.Appearance.Options.UseBackColor = true;
            simpleButtonClearKnitMachine.Appearance.Options.UseFont = true;
            simpleButtonClearKnitMachine.Appearance.Options.UseForeColor = true;
            simpleButtonClearKnitMachine.AppearanceDisabled.BackColor = System.Drawing.Color.Green;
            simpleButtonClearKnitMachine.AppearanceDisabled.ForeColor = System.Drawing.Color.GreenYellow;
            simpleButtonClearKnitMachine.AppearanceDisabled.Options.UseBackColor = true;
            simpleButtonClearKnitMachine.AppearanceDisabled.Options.UseForeColor = true;
            tablePanel1.SetColumn(simpleButtonClearKnitMachine, 10);
            simpleButtonClearKnitMachine.Dock = System.Windows.Forms.DockStyle.Top;
            simpleButtonClearKnitMachine.ImageOptions.Image = (System.Drawing.Image)resources.GetObject("simpleButtonClearKnitMachine.ImageOptions.Image");
            simpleButtonClearKnitMachine.Location = new System.Drawing.Point(1486, 480);
            simpleButtonClearKnitMachine.Name = "simpleButtonClearKnitMachine";
            tablePanel1.SetRow(simpleButtonClearKnitMachine, 3);
            simpleButtonClearKnitMachine.Size = new System.Drawing.Size(288, 24);
            simpleButtonClearKnitMachine.TabIndex = 37;
            simpleButtonClearKnitMachine.Text = "Очистить В/М";
            simpleButtonClearKnitMachine.Click += simpleButtonClearKnitMachine_Click;
            // 
            // gridControlPlanSezonZadanyRazmKol
            // 
            gridControlPlanSezonZadanyRazmKol.Dock = System.Windows.Forms.DockStyle.Fill;
            gridControlPlanSezonZadanyRazmKol.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlPlanSezonZadanyRazmKol.Font = new System.Drawing.Font("Arial", 10F);
            gridControlPlanSezonZadanyRazmKol.Location = new System.Drawing.Point(328, 527);
            gridControlPlanSezonZadanyRazmKol.MainView = gridView2;
            gridControlPlanSezonZadanyRazmKol.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlPlanSezonZadanyRazmKol.Name = "gridControlPlanSezonZadanyRazmKol";
            gridControlPlanSezonZadanyRazmKol.Size = new System.Drawing.Size(232, 231);
            gridControlPlanSezonZadanyRazmKol.TabIndex = 30;
            gridControlPlanSezonZadanyRazmKol.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView2 });
            // 
            // gridView2
            // 
            gridView2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(255, 223, 196);
            gridView2.Appearance.EvenRow.Options.UseBackColor = true;
            gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { gridColumnPlanSezonZadanyRazmKolKol, gridColumnPlanSezonZadanyRazmKolRazm });
            gridView2.DetailHeight = 404;
            gridView2.GridControl = gridControlPlanSezonZadanyRazmKol;
            gridView2.Name = "gridView2";
            gridView2.OptionsEditForm.PopupEditFormWidth = 933;
            gridView2.OptionsView.EnableAppearanceEvenRow = true;
            gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumnPlanSezonZadanyRazmKolKol
            // 
            gridColumnPlanSezonZadanyRazmKolKol.Caption = "Количество";
            gridColumnPlanSezonZadanyRazmKolKol.MinWidth = 23;
            gridColumnPlanSezonZadanyRazmKolKol.Name = "gridColumnPlanSezonZadanyRazmKolKol";
            gridColumnPlanSezonZadanyRazmKolKol.Visible = true;
            gridColumnPlanSezonZadanyRazmKolKol.VisibleIndex = 1;
            gridColumnPlanSezonZadanyRazmKolKol.Width = 87;
            // 
            // gridColumnPlanSezonZadanyRazmKolRazm
            // 
            gridColumnPlanSezonZadanyRazmKolRazm.Caption = "Размер";
            gridColumnPlanSezonZadanyRazmKolRazm.MinWidth = 23;
            gridColumnPlanSezonZadanyRazmKolRazm.Name = "gridColumnPlanSezonZadanyRazmKolRazm";
            gridColumnPlanSezonZadanyRazmKolRazm.Visible = true;
            gridColumnPlanSezonZadanyRazmKolRazm.VisibleIndex = 0;
            gridColumnPlanSezonZadanyRazmKolRazm.Width = 87;
            // 
            // simpleButtonSetKnitMachine
            // 
            simpleButtonSetKnitMachine.Appearance.BackColor = System.Drawing.Color.FromArgb(255, 223, 196);
            simpleButtonSetKnitMachine.Appearance.Font = new System.Drawing.Font("Arial", 10F);
            simpleButtonSetKnitMachine.Appearance.ForeColor = System.Drawing.Color.FromArgb(139, 69, 19);
            simpleButtonSetKnitMachine.Appearance.Options.UseBackColor = true;
            simpleButtonSetKnitMachine.Appearance.Options.UseFont = true;
            simpleButtonSetKnitMachine.Appearance.Options.UseForeColor = true;
            simpleButtonSetKnitMachine.AppearanceDisabled.BackColor = System.Drawing.Color.Green;
            simpleButtonSetKnitMachine.AppearanceDisabled.ForeColor = System.Drawing.Color.GreenYellow;
            simpleButtonSetKnitMachine.AppearanceDisabled.Options.UseBackColor = true;
            simpleButtonSetKnitMachine.AppearanceDisabled.Options.UseForeColor = true;
            tablePanel1.SetColumn(simpleButtonSetKnitMachine, 10);
            simpleButtonSetKnitMachine.ImageOptions.Image = (System.Drawing.Image)resources.GetObject("simpleButtonSetKnitMachine.ImageOptions.Image");
            simpleButtonSetKnitMachine.Location = new System.Drawing.Point(1488, 437);
            simpleButtonSetKnitMachine.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            simpleButtonSetKnitMachine.Name = "simpleButtonSetKnitMachine";
            tablePanel1.SetRow(simpleButtonSetKnitMachine, 1);
            simpleButtonSetKnitMachine.Size = new System.Drawing.Size(284, 24);
            simpleButtonSetKnitMachine.TabIndex = 32;
            simpleButtonSetKnitMachine.Text = "Привязать В/М";
            simpleButtonSetKnitMachine.Click += simpleButtonSetKnitMachine_Click;
            // 
            // gridControlArtPrFioProgr
            // 
            gridControlArtPrFioProgr.Dock = System.Windows.Forms.DockStyle.Fill;
            gridControlArtPrFioProgr.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrFioProgr.Font = new System.Drawing.Font("Arial", 10F);
            gridControlArtPrFioProgr.Location = new System.Drawing.Point(15, 776);
            gridControlArtPrFioProgr.MainView = gridView1;
            gridControlArtPrFioProgr.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            gridControlArtPrFioProgr.Name = "gridControlArtPrFioProgr";
            gridControlArtPrFioProgr.Size = new System.Drawing.Size(545, 176);
            gridControlArtPrFioProgr.TabIndex = 29;
            gridControlArtPrFioProgr.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView1 });
            // 
            // gridView1
            // 
            gridView1.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(255, 223, 196);
            gridView1.Appearance.EvenRow.Options.UseBackColor = true;
            gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { gridColumn1, gridColumn2, gridColumnArtPrFioProgrRazm, gridColumnArtPrFioProgrArticul });
            gridView1.DetailHeight = 404;
            gridView1.GridControl = gridControlArtPrFioProgr;
            gridView1.Name = "gridView1";
            gridView1.OptionsEditForm.PopupEditFormWidth = 933;
            gridView1.OptionsView.EnableAppearanceEvenRow = true;
            gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            gridColumn1.MinWidth = 23;
            gridColumn1.Name = "gridColumn1";
            gridColumn1.Visible = true;
            gridColumn1.VisibleIndex = 3;
            gridColumn1.Width = 87;
            // 
            // gridColumn2
            // 
            gridColumn2.MinWidth = 23;
            gridColumn2.Name = "gridColumn2";
            gridColumn2.Visible = true;
            gridColumn2.VisibleIndex = 2;
            gridColumn2.Width = 87;
            // 
            // gridColumnArtPrFioProgrRazm
            // 
            gridColumnArtPrFioProgrRazm.Caption = "Размер";
            gridColumnArtPrFioProgrRazm.MinWidth = 23;
            gridColumnArtPrFioProgrRazm.Name = "gridColumnArtPrFioProgrRazm";
            gridColumnArtPrFioProgrRazm.Visible = true;
            gridColumnArtPrFioProgrRazm.VisibleIndex = 1;
            gridColumnArtPrFioProgrRazm.Width = 87;
            // 
            // gridColumnArtPrFioProgrArticul
            // 
            gridColumnArtPrFioProgrArticul.Caption = "Артикул";
            gridColumnArtPrFioProgrArticul.MinWidth = 23;
            gridColumnArtPrFioProgrArticul.Name = "gridColumnArtPrFioProgrArticul";
            gridColumnArtPrFioProgrArticul.Visible = true;
            gridColumnArtPrFioProgrArticul.VisibleIndex = 0;
            gridColumnArtPrFioProgrArticul.Width = 87;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 198F));
            tableLayoutPanel1.Controls.Add(customTextBox1, 1, 0);
            tableLayoutPanel1.Controls.Add(customLabel1, 0, 0);
            tableLayoutPanel1.Location = new System.Drawing.Point(15, 481);
            tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            tableLayoutPanel1.Size = new System.Drawing.Size(305, 28);
            tableLayoutPanel1.TabIndex = 28;
            // 
            // customTextBox1
            // 
            customTextBox1.BackColor = System.Drawing.Color.FromArgb(255, 245, 230);
            customTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            customTextBox1.Font = new System.Drawing.Font("Arial", 10F);
            customTextBox1.ForeColor = System.Drawing.Color.FromArgb(120, 60, 30);
            customTextBox1.Location = new System.Drawing.Point(111, 3);
            customTextBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            customTextBox1.Name = "customTextBox1";
            customTextBox1.Size = new System.Drawing.Size(190, 23);
            customTextBox1.TabIndex = 1;
            // 
            // customLabel1
            // 
            customLabel1.AutoSize = true;
            customLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            customLabel1.Font = new System.Drawing.Font("Arial", 10F);
            customLabel1.ForeColor = System.Drawing.Color.FromArgb(139, 69, 19);
            customLabel1.Location = new System.Drawing.Point(4, 3);
            customLabel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            customLabel1.Name = "customLabel1";
            customLabel1.Size = new System.Drawing.Size(99, 22);
            customLabel1.TabIndex = 0;
            customLabel1.Text = "Программист";
            customLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gridColumn4
            // 
            gridColumn4.Caption = "Артикул";
            gridColumn4.Name = "gridColumn4";
            gridColumn4.Visible = true;
            gridColumn4.VisibleIndex = 0;
            // 
            // simpleSeparator1
            // 
            simpleSeparator1.Location = new System.Drawing.Point(0, 26);
            simpleSeparator1.Name = "simpleSeparator1";
            simpleSeparator1.Size = new System.Drawing.Size(171, 1);
            // 
            // KnittingProductionPlanning
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1787, 966);
            Controls.Add(tablePanel1);
            Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            Name = "KnittingProductionPlanning";
            Text = "Оперативное планирование вязального производства";
            Load += KnittingProductionPlanning_Load;
            ((System.ComponentModel.ISupportInitialize)gridControlVyazPlan).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridViewVyazPlan).EndInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemCheckEdit1).EndInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemCheckedComboBoxEdit1).EndInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemLookUpEdit1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxEskiz).EndInit();
            ((System.ComponentModel.ISupportInitialize)tablePanel1).EndInit();
            tablePanel1.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)tablePanel3).EndInit();
            tablePanel3.ResumeLayout(false);
            tablePanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrKnitMachineViewPr2).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView5).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrKnitMachineViewRecom2).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView6).EndInit();
            ((System.ComponentModel.ISupportInitialize)tablePanel2).EndInit();
            tablePanel2.ResumeLayout(false);
            tablePanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrKnitMachineViewPr1).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView3).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrKnitMachineViewRecom1).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView4).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridControlPlanSezonZadanyRazmKol).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridControlArtPrFioProgr).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)simpleSeparator1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private CustomGridControl gridControlVyazPlan;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewVyazPlan;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanPszkmPlanDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanKmlNumber;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanSekVyazAll;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanKol;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanZvetTkan;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanSekVyaz;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanNameVyazClass;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanGrup;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanArticul;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanDateCdPlan;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanNameSbit;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanDateZap;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanNomZad;
        private DevExpress.Utils.Layout.TablePanel tablePanel1;
        private System.Windows.Forms.PictureBox pictureBoxEskiz;
        private CustomTextBox customTextBox1;
        private CustomLabel customLabel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private CustomGridControl gridControlArtPrFioProgr;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private CustomGridControl gridControlPlanSezonZadanyRazmKol;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrFioProgrRazm;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrFioProgrArticul;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPlanSezonZadanyRazmKolKol;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPlanSezonZadanyRazmKolRazm;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanSyncSelection;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private CustomSimpleButton simpleButtonSaveVyaz;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckedComboBoxEdit repositoryItemCheckedComboBoxEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private CustomSimpleButton simpleButtonSetKnitMachine;
        private CustomGridControl gridControlArtPrKnitMachineViewPr1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private CustomGridControl gridControlArtPrKnitMachineViewRecom1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
        private CustomLabel customLabel2;
        private CustomComboBox comboBoxKnitMachineList;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnVyazPlanNn;
        private CustomGridControl gridControlArtPrKnitMachineViewRecom2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView6;
        private CustomGridControl gridControlArtPrKnitMachineViewPr2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrKnitMachineViewPr1KmlNumber;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrKnitMachineViewRecom2AvailableHoursCurrMonth;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrKnitMachineViewRecom2KmlNumber;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrKnitMachineViewPr2KmlNumber;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrKnitMachineViewRecom1AvailableHoursCurrMonth;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrKnitMachineViewRecom1KmlNumber;
        private DevExpress.Utils.Layout.TablePanel tablePanel2;
        private DevExpress.Utils.Layout.TablePanel tablePanel3;
        private CustomLabel customLabel3;
        private CustomLabel customLabel4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrKnitMachineViewRecom2AvailableHoursNextMonth;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnArtPrKnitMachineViewRecom1AvailableHoursNextMonth;
        private CustomSimpleButton simpleButtonClearKnitMachine;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
    }
}