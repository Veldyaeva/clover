﻿namespace SewingProduction.Features.Sprav
{
    partial class EditTarif
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditTarif));
            customTabControlZpTarif = new CustomTabControl();
            xtraTabPageZP = new DevExpress.XtraTab.XtraTabPage();
            tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            customGroupBoxFiltr = new CustomGroupBox();
            customRadioButtonMay = new CustomRadioButton();
            customRadioButtonAll = new CustomRadioButton();
            customRadioButtonExp = new CustomRadioButton();
            customRadioButtonAceKle = new CustomRadioButton();
            customGridControlZp = new Core.Class.CustomGridControl();
            gridViewZp = new DevExpress.XtraGrid.Views.Grid.GridView();
            describe = new DevExpress.XtraGrid.Columns.GridColumn();
            begin_dt = new DevExpress.XtraGrid.Columns.GridColumn();
            value_numeric = new DevExpress.XtraGrid.Columns.GridColumn();
            value_integer = new DevExpress.XtraGrid.Columns.GridColumn();
            value_float = new DevExpress.XtraGrid.Columns.GridColumn();
            value_character = new DevExpress.XtraGrid.Columns.GridColumn();
            value_datetime = new DevExpress.XtraGrid.Columns.GridColumn();
            firm = new DevExpress.XtraGrid.Columns.GridColumn();
            customGroupBoxAdd = new CustomGroupBox();
            tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            customComboBoxOrg = new CustomComboBox();
            customTextBoxOpis = new CustomTextBox();
            customLabelNull = new CustomLabel();
            customLabelOrg = new CustomLabel();
            customLabelZnach = new CustomLabel();
            customLabelDate = new CustomLabel();
            customLabelType = new CustomLabel();
            customLabelOpis = new CustomLabel();
            customLabelRazm = new CustomLabel();
            customTextBoxName = new CustomTextBox();
            customLabelName = new CustomLabel();
            customTextBoxZnach = new CustomTextBox();
            customTextBoxRazm = new CustomTextBox();
            customCheckBoxNotRazm = new CustomCheckBox();
            customButtonOtm = new Core.Class.CustomButton();
            customButtonSave = new Core.Class.CustomButton();
            customComboBoxType = new CustomComboBox();
            customDateTimePickerBegin = new CustomDateTimePicker();
            customButtonAdd = new Core.Class.CustomButton();
            customGridControlHistory = new Core.Class.CustomGridControl();
            gridViewHistory = new DevExpress.XtraGrid.Views.Grid.GridView();
            customGridControlTR = new Core.Class.CustomGridControl();
            gridViewTR = new DevExpress.XtraGrid.Views.Grid.GridView();
            id_kod_o = new DevExpress.XtraGrid.Columns.GridColumn();
            prizn_podr = new DevExpress.XtraGrid.Columns.GridColumn();
            tarif = new DevExpress.XtraGrid.Columns.GridColumn();
            ed_izm = new DevExpress.XtraGrid.Columns.GridColumn();
            koef_chas = new DevExpress.XtraGrid.Columns.GridColumn();
            razr = new DevExpress.XtraGrid.Columns.GridColumn();
            Text = new DevExpress.XtraGrid.Columns.GridColumn();
            xtraTabPageTarif = new DevExpress.XtraTab.XtraTabPage();
            Название = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)customTabControlZpTarif).BeginInit();
            customTabControlZpTarif.SuspendLayout();
            xtraTabPageZP.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            customGroupBoxFiltr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)customGridControlZp).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridViewZp).BeginInit();
            customGroupBoxAdd.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)customGridControlHistory).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridViewHistory).BeginInit();
            ((System.ComponentModel.ISupportInitialize)customGridControlTR).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridViewTR).BeginInit();
            SuspendLayout();
            // 
            // customTabControlZpTarif
            // 
            customTabControlZpTarif.Appearance.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customTabControlZpTarif.Appearance.Options.UseForeColor = true;
            customTabControlZpTarif.Dock = System.Windows.Forms.DockStyle.Fill;
            customTabControlZpTarif.Location = new System.Drawing.Point(0, 0);
            customTabControlZpTarif.Name = "customTabControlZpTarif";
            customTabControlZpTarif.ObjectName = null;
            customTabControlZpTarif.SelectedTabPage = xtraTabPageZP;
            customTabControlZpTarif.Size = new System.Drawing.Size(1121, 663);
            customTabControlZpTarif.TabIndex = 0;
            customTabControlZpTarif.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] { xtraTabPageZP, xtraTabPageTarif });
            // 
            // xtraTabPageZP
            // 
            xtraTabPageZP.Controls.Add(tableLayoutPanel1);
            xtraTabPageZP.Name = "xtraTabPageZP";
            xtraTabPageZP.Size = new System.Drawing.Size(1119, 638);
            xtraTabPageZP.Text = "Зарплата";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.5755138F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.6899014F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.6005363F));
            tableLayoutPanel1.Controls.Add(customGroupBoxFiltr, 0, 0);
            tableLayoutPanel1.Controls.Add(customGridControlZp, 0, 1);
            tableLayoutPanel1.Controls.Add(customGroupBoxAdd, 2, 3);
            tableLayoutPanel1.Controls.Add(customButtonAdd, 2, 1);
            tableLayoutPanel1.Controls.Add(customGridControlHistory, 0, 4);
            tableLayoutPanel1.Controls.Add(customGridControlTR, 1, 4);
            tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.8589344F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.48589325F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.48589325F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.8213158F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.3479633F));
            tableLayoutPanel1.Size = new System.Drawing.Size(1119, 638);
            tableLayoutPanel1.TabIndex = 3;
            // 
            // customGroupBoxFiltr
            // 
            customGroupBoxFiltr.BackColor = System.Drawing.Color.Transparent;
            customGroupBoxFiltr.Controls.Add(customRadioButtonMay);
            customGroupBoxFiltr.Controls.Add(customRadioButtonAll);
            customGroupBoxFiltr.Controls.Add(customRadioButtonExp);
            customGroupBoxFiltr.Controls.Add(customRadioButtonAceKle);
            customGroupBoxFiltr.Dock = System.Windows.Forms.DockStyle.Fill;
            customGroupBoxFiltr.Location = new System.Drawing.Point(3, 3);
            customGroupBoxFiltr.Name = "customGroupBoxFiltr";
            customGroupBoxFiltr.Size = new System.Drawing.Size(554, 25);
            customGroupBoxFiltr.TabIndex = 1;
            customGroupBoxFiltr.TabStop = false;
            // 
            // customRadioButtonMay
            // 
            customRadioButtonMay.Anchor = System.Windows.Forms.AnchorStyles.None;
            customRadioButtonMay.AutoSize = true;
            customRadioButtonMay.Font = new System.Drawing.Font("Arial", 10F);
            customRadioButtonMay.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customRadioButtonMay.Location = new System.Drawing.Point(277, 0);
            customRadioButtonMay.Name = "customRadioButtonMay";
            customRadioButtonMay.ObjectName = null;
            customRadioButtonMay.Size = new System.Drawing.Size(52, 20);
            customRadioButtonMay.TabIndex = 3;
            customRadioButtonMay.TabStop = true;
            customRadioButtonMay.Text = "Май";
            customRadioButtonMay.UseVisualStyleBackColor = true;
            customRadioButtonMay.CheckedChanged += Filter;
            // 
            // customRadioButtonAll
            // 
            customRadioButtonAll.Anchor = System.Windows.Forms.AnchorStyles.None;
            customRadioButtonAll.AutoSize = true;
            customRadioButtonAll.Checked = true;
            customRadioButtonAll.Font = new System.Drawing.Font("Arial", 10F);
            customRadioButtonAll.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customRadioButtonAll.Location = new System.Drawing.Point(359, 0);
            customRadioButtonAll.Name = "customRadioButtonAll";
            customRadioButtonAll.ObjectName = null;
            customRadioButtonAll.Size = new System.Drawing.Size(49, 20);
            customRadioButtonAll.TabIndex = 2;
            customRadioButtonAll.TabStop = true;
            customRadioButtonAll.Text = "Все";
            customRadioButtonAll.UseVisualStyleBackColor = true;
            customRadioButtonAll.CheckedChanged += Filter;
            // 
            // customRadioButtonExp
            // 
            customRadioButtonExp.Anchor = System.Windows.Forms.AnchorStyles.None;
            customRadioButtonExp.AutoSize = true;
            customRadioButtonExp.Font = new System.Drawing.Font("Arial", 10F);
            customRadioButtonExp.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customRadioButtonExp.Location = new System.Drawing.Point(131, 0);
            customRadioButtonExp.Name = "customRadioButtonExp";
            customRadioButtonExp.ObjectName = null;
            customRadioButtonExp.Size = new System.Drawing.Size(113, 20);
            customRadioButtonExp.TabIndex = 1;
            customRadioButtonExp.Text = "Эксперимент";
            customRadioButtonExp.UseVisualStyleBackColor = true;
            customRadioButtonExp.CheckedChanged += Filter;
            // 
            // customRadioButtonAceKle
            // 
            customRadioButtonAceKle.Anchor = System.Windows.Forms.AnchorStyles.None;
            customRadioButtonAceKle.AutoSize = true;
            customRadioButtonAceKle.Font = new System.Drawing.Font("Arial", 10F);
            customRadioButtonAceKle.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customRadioButtonAceKle.Location = new System.Drawing.Point(5, 0);
            customRadioButtonAceKle.Name = "customRadioButtonAceKle";
            customRadioButtonAceKle.ObjectName = null;
            customRadioButtonAceKle.Size = new System.Drawing.Size(105, 20);
            customRadioButtonAceKle.TabIndex = 0;
            customRadioButtonAceKle.Text = "Эйс, Клевер";
            customRadioButtonAceKle.UseVisualStyleBackColor = true;
            customRadioButtonAceKle.CheckedChanged += Filter;
            // 
            // customGridControlZp
            // 
            tableLayoutPanel1.SetColumnSpan(customGridControlZp, 2);
            customGridControlZp.Dock = System.Windows.Forms.DockStyle.Fill;
            customGridControlZp.Font = new System.Drawing.Font("Arial", 10F);
            customGridControlZp.Location = new System.Drawing.Point(3, 34);
            customGridControlZp.MainView = gridViewZp;
            customGridControlZp.Name = "customGridControlZp";
            tableLayoutPanel1.SetRowSpan(customGridControlZp, 3);
            customGridControlZp.Size = new System.Drawing.Size(829, 401);
            customGridControlZp.TabIndex = 2;
            customGridControlZp.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridViewZp });
            customGridControlZp.Load += customGridControlZp_Load;
            // 
            // gridViewZp
            // 
            gridViewZp.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            gridViewZp.Appearance.EvenRow.Options.UseBackColor = true;
            gridViewZp.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            gridViewZp.Appearance.FocusedRow.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            gridViewZp.Appearance.FocusedRow.Options.UseBackColor = true;
            gridViewZp.Appearance.FocusedRow.Options.UseFont = true;
            gridViewZp.Appearance.GroupRow.Options.UseTextOptions = true;
            gridViewZp.Appearance.GroupRow.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            gridViewZp.Appearance.HeaderPanel.Options.UseTextOptions = true;
            gridViewZp.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            gridViewZp.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { describe, begin_dt, value_numeric, value_integer, value_float, value_character, value_datetime, firm });
            gridViewZp.GridControl = customGridControlZp;
            gridViewZp.Name = "gridViewZp";
            gridViewZp.OptionsView.EnableAppearanceEvenRow = true;
            // 
            // describe
            // 
            describe.AppearanceCell.Options.UseTextOptions = true;
            describe.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            describe.AppearanceHeader.Options.UseTextOptions = true;
            describe.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            describe.Caption = "Наименование";
            describe.FieldName = "describe";
            describe.Name = "describe";
            describe.Visible = true;
            describe.VisibleIndex = 0;
            describe.Width = 187;
            // 
            // begin_dt
            // 
            begin_dt.AppearanceCell.Options.UseTextOptions = true;
            begin_dt.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            begin_dt.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            begin_dt.AppearanceHeader.Options.UseTextOptions = true;
            begin_dt.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            begin_dt.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            begin_dt.Caption = "Дата начала действия";
            begin_dt.FieldName = "begin_dt";
            begin_dt.Name = "begin_dt";
            begin_dt.Visible = true;
            begin_dt.VisibleIndex = 2;
            begin_dt.Width = 87;
            // 
            // value_numeric
            // 
            value_numeric.AppearanceCell.Options.UseTextOptions = true;
            value_numeric.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_numeric.AppearanceHeader.Options.UseTextOptions = true;
            value_numeric.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_numeric.Caption = "Значение numeric";
            value_numeric.FieldName = "value_numeric";
            value_numeric.Name = "value_numeric";
            value_numeric.Visible = true;
            value_numeric.VisibleIndex = 3;
            value_numeric.Width = 87;
            // 
            // value_integer
            // 
            value_integer.AppearanceCell.Options.UseTextOptions = true;
            value_integer.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_integer.AppearanceHeader.Options.UseTextOptions = true;
            value_integer.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_integer.Caption = "Значение integer";
            value_integer.FieldName = "value_integer";
            value_integer.Name = "value_integer";
            value_integer.Visible = true;
            value_integer.VisibleIndex = 4;
            value_integer.Width = 87;
            // 
            // value_float
            // 
            value_float.AppearanceCell.Options.UseTextOptions = true;
            value_float.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_float.AppearanceHeader.Options.UseTextOptions = true;
            value_float.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_float.Caption = "Значение float";
            value_float.FieldName = "value_float";
            value_float.Name = "value_float";
            value_float.Visible = true;
            value_float.VisibleIndex = 7;
            value_float.Width = 87;
            // 
            // value_character
            // 
            value_character.AppearanceCell.Options.UseTextOptions = true;
            value_character.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_character.AppearanceHeader.Options.UseTextOptions = true;
            value_character.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_character.Caption = "Значение character";
            value_character.FieldName = "value_character";
            value_character.Name = "value_character";
            value_character.Visible = true;
            value_character.VisibleIndex = 5;
            value_character.Width = 87;
            // 
            // value_datetime
            // 
            value_datetime.AppearanceCell.Options.UseTextOptions = true;
            value_datetime.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_datetime.AppearanceHeader.Options.UseTextOptions = true;
            value_datetime.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            value_datetime.Caption = "Значение datetime";
            value_datetime.FieldName = "value_datetime";
            value_datetime.Name = "value_datetime";
            value_datetime.Visible = true;
            value_datetime.VisibleIndex = 6;
            value_datetime.Width = 97;
            // 
            // firm
            // 
            firm.AppearanceCell.Options.UseTextOptions = true;
            firm.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            firm.AppearanceHeader.Options.UseTextOptions = true;
            firm.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            firm.Caption = "Организация";
            firm.FieldName = "firm";
            firm.Name = "firm";
            firm.Visible = true;
            firm.VisibleIndex = 1;
            firm.Width = 87;
            // 
            // customGroupBoxAdd
            // 
            customGroupBoxAdd.BackColor = System.Drawing.Color.Transparent;
            tableLayoutPanel1.SetColumnSpan(customGroupBoxAdd, 2);
            customGroupBoxAdd.Controls.Add(tableLayoutPanel2);
            customGroupBoxAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            customGroupBoxAdd.Location = new System.Drawing.Point(838, 104);
            customGroupBoxAdd.Name = "customGroupBoxAdd";
            customGroupBoxAdd.Size = new System.Drawing.Size(278, 331);
            customGroupBoxAdd.TabIndex = 4;
            customGroupBoxAdd.TabStop = false;
            customGroupBoxAdd.Text = "Добавление";
            customGroupBoxAdd.Visible = false;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            tableLayoutPanel2.Controls.Add(customComboBoxOrg, 1, 7);
            tableLayoutPanel2.Controls.Add(customTextBoxOpis, 1, 3);
            tableLayoutPanel2.Controls.Add(customLabelNull, 0, 2);
            tableLayoutPanel2.Controls.Add(customLabelOrg, 0, 7);
            tableLayoutPanel2.Controls.Add(customLabelZnach, 0, 6);
            tableLayoutPanel2.Controls.Add(customLabelDate, 0, 5);
            tableLayoutPanel2.Controls.Add(customLabelType, 0, 4);
            tableLayoutPanel2.Controls.Add(customLabelOpis, 0, 3);
            tableLayoutPanel2.Controls.Add(customLabelRazm, 0, 1);
            tableLayoutPanel2.Controls.Add(customTextBoxName, 1, 0);
            tableLayoutPanel2.Controls.Add(customLabelName, 0, 0);
            tableLayoutPanel2.Controls.Add(customTextBoxZnach, 1, 6);
            tableLayoutPanel2.Controls.Add(customTextBoxRazm, 1, 1);
            tableLayoutPanel2.Controls.Add(customCheckBoxNotRazm, 1, 2);
            tableLayoutPanel2.Controls.Add(customButtonOtm, 0, 8);
            tableLayoutPanel2.Controls.Add(customButtonSave, 1, 8);
            tableLayoutPanel2.Controls.Add(customComboBoxType, 1, 4);
            tableLayoutPanel2.Controls.Add(customDateTimePickerBegin, 1, 5);
            tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            tableLayoutPanel2.Location = new System.Drawing.Point(3, 17);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 9;
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.Size = new System.Drawing.Size(272, 311);
            tableLayoutPanel2.TabIndex = 3;
            // 
            // customComboBoxOrg
            // 
            customComboBoxOrg.BackColor = System.Drawing.Color.FromArgb(245, 245, 250);
            customComboBoxOrg.Dock = System.Windows.Forms.DockStyle.Fill;
            customComboBoxOrg.Font = new System.Drawing.Font("Arial", 10F);
            customComboBoxOrg.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customComboBoxOrg.FormattingEnabled = true;
            customComboBoxOrg.Location = new System.Drawing.Point(84, 254);
            customComboBoxOrg.Name = "customComboBoxOrg";
            customComboBoxOrg.Size = new System.Drawing.Size(185, 24);
            customComboBoxOrg.TabIndex = 43;
            // 
            // customTextBoxOpis
            // 
            customTextBoxOpis.BackColor = System.Drawing.Color.FromArgb(245, 245, 250);
            customTextBoxOpis.Dock = System.Windows.Forms.DockStyle.Fill;
            customTextBoxOpis.Font = new System.Drawing.Font("Arial", 10F);
            customTextBoxOpis.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customTextBoxOpis.Location = new System.Drawing.Point(84, 90);
            customTextBoxOpis.Multiline = true;
            customTextBoxOpis.Name = "customTextBoxOpis";
            customTextBoxOpis.Size = new System.Drawing.Size(185, 51);
            customTextBoxOpis.TabIndex = 41;
            // 
            // customLabelNull
            // 
            customLabelNull.AutoSize = true;
            customLabelNull.Dock = System.Windows.Forms.DockStyle.Left;
            customLabelNull.Font = new System.Drawing.Font("Arial", 10F);
            customLabelNull.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customLabelNull.Location = new System.Drawing.Point(3, 61);
            customLabelNull.Name = "customLabelNull";
            customLabelNull.Size = new System.Drawing.Size(0, 26);
            customLabelNull.TabIndex = 40;
            customLabelNull.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customLabelOrg
            // 
            customLabelOrg.AutoSize = true;
            customLabelOrg.Dock = System.Windows.Forms.DockStyle.Left;
            customLabelOrg.Font = new System.Drawing.Font("Arial", 10F);
            customLabelOrg.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customLabelOrg.Location = new System.Drawing.Point(3, 251);
            customLabelOrg.Name = "customLabelOrg";
            customLabelOrg.Size = new System.Drawing.Size(69, 32);
            customLabelOrg.TabIndex = 39;
            customLabelOrg.Text = "Организация";
            customLabelOrg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customLabelZnach
            // 
            customLabelZnach.AutoSize = true;
            customLabelZnach.Dock = System.Windows.Forms.DockStyle.Left;
            customLabelZnach.Font = new System.Drawing.Font("Arial", 10F);
            customLabelZnach.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customLabelZnach.Location = new System.Drawing.Point(3, 222);
            customLabelZnach.Name = "customLabelZnach";
            customLabelZnach.Size = new System.Drawing.Size(70, 29);
            customLabelZnach.TabIndex = 38;
            customLabelZnach.Text = "Значение";
            customLabelZnach.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customLabelDate
            // 
            customLabelDate.AutoSize = true;
            customLabelDate.Dock = System.Windows.Forms.DockStyle.Left;
            customLabelDate.Font = new System.Drawing.Font("Arial", 10F);
            customLabelDate.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customLabelDate.Location = new System.Drawing.Point(3, 174);
            customLabelDate.Name = "customLabelDate";
            customLabelDate.Size = new System.Drawing.Size(68, 48);
            customLabelDate.TabIndex = 37;
            customLabelDate.Text = "Дата начала действия";
            // 
            // customLabelType
            // 
            customLabelType.AutoSize = true;
            customLabelType.Dock = System.Windows.Forms.DockStyle.Left;
            customLabelType.Font = new System.Drawing.Font("Arial", 10F);
            customLabelType.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customLabelType.Location = new System.Drawing.Point(3, 144);
            customLabelType.Name = "customLabelType";
            customLabelType.Size = new System.Drawing.Size(31, 30);
            customLabelType.TabIndex = 36;
            customLabelType.Text = "Тип";
            customLabelType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customLabelOpis
            // 
            customLabelOpis.AutoSize = true;
            customLabelOpis.Dock = System.Windows.Forms.DockStyle.Left;
            customLabelOpis.Font = new System.Drawing.Font("Arial", 10F);
            customLabelOpis.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customLabelOpis.Location = new System.Drawing.Point(3, 87);
            customLabelOpis.Name = "customLabelOpis";
            customLabelOpis.Size = new System.Drawing.Size(73, 57);
            customLabelOpis.TabIndex = 34;
            customLabelOpis.Text = "Описание";
            customLabelOpis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customLabelRazm
            // 
            customLabelRazm.AutoSize = true;
            customLabelRazm.Dock = System.Windows.Forms.DockStyle.Left;
            customLabelRazm.Font = new System.Drawing.Font("Arial", 10F);
            customLabelRazm.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customLabelRazm.Location = new System.Drawing.Point(3, 29);
            customLabelRazm.Name = "customLabelRazm";
            customLabelRazm.Size = new System.Drawing.Size(72, 32);
            customLabelRazm.TabIndex = 31;
            customLabelRazm.Text = "Размерность";
            customLabelRazm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customTextBoxName
            // 
            customTextBoxName.BackColor = System.Drawing.Color.FromArgb(245, 245, 250);
            customTextBoxName.Dock = System.Windows.Forms.DockStyle.Fill;
            customTextBoxName.Font = new System.Drawing.Font("Arial", 10F);
            customTextBoxName.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customTextBoxName.Location = new System.Drawing.Point(84, 3);
            customTextBoxName.Name = "customTextBoxName";
            customTextBoxName.Size = new System.Drawing.Size(185, 23);
            customTextBoxName.TabIndex = 30;
            // 
            // customLabelName
            // 
            customLabelName.AutoSize = true;
            customLabelName.Dock = System.Windows.Forms.DockStyle.Left;
            customLabelName.Font = new System.Drawing.Font("Arial", 10F);
            customLabelName.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customLabelName.Location = new System.Drawing.Point(3, 0);
            customLabelName.Name = "customLabelName";
            customLabelName.Size = new System.Drawing.Size(35, 29);
            customLabelName.TabIndex = 26;
            customLabelName.Text = "Имя";
            customLabelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // customTextBoxZnach
            // 
            customTextBoxZnach.BackColor = System.Drawing.Color.FromArgb(245, 245, 250);
            customTextBoxZnach.Dock = System.Windows.Forms.DockStyle.Fill;
            customTextBoxZnach.Font = new System.Drawing.Font("Arial", 10F);
            customTextBoxZnach.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customTextBoxZnach.Location = new System.Drawing.Point(84, 225);
            customTextBoxZnach.Name = "customTextBoxZnach";
            customTextBoxZnach.Size = new System.Drawing.Size(185, 23);
            customTextBoxZnach.TabIndex = 21;
            // 
            // customTextBoxRazm
            // 
            customTextBoxRazm.BackColor = System.Drawing.Color.FromArgb(245, 245, 250);
            customTextBoxRazm.Dock = System.Windows.Forms.DockStyle.Fill;
            customTextBoxRazm.Font = new System.Drawing.Font("Arial", 10F);
            customTextBoxRazm.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customTextBoxRazm.Location = new System.Drawing.Point(84, 32);
            customTextBoxRazm.Name = "customTextBoxRazm";
            customTextBoxRazm.Size = new System.Drawing.Size(185, 23);
            customTextBoxRazm.TabIndex = 0;
            // 
            // customCheckBoxNotRazm
            // 
            customCheckBoxNotRazm.AutoSize = true;
            customCheckBoxNotRazm.Font = new System.Drawing.Font("Arial", 10F);
            customCheckBoxNotRazm.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customCheckBoxNotRazm.Location = new System.Drawing.Point(84, 64);
            customCheckBoxNotRazm.Name = "customCheckBoxNotRazm";
            customCheckBoxNotRazm.Size = new System.Drawing.Size(139, 20);
            customCheckBoxNotRazm.TabIndex = 33;
            customCheckBoxNotRazm.Text = "нет размерности";
            customCheckBoxNotRazm.UseVisualStyleBackColor = true;
            customCheckBoxNotRazm.CheckedChanged += customCheckBoxNotRazm_CheckedChanged;
            // 
            // customButtonOtm
            // 
            customButtonOtm.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            customButtonOtm.Dock = System.Windows.Forms.DockStyle.Fill;
            customButtonOtm.Font = new System.Drawing.Font("Arial", 10F);
            customButtonOtm.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customButtonOtm.Location = new System.Drawing.Point(3, 286);
            customButtonOtm.MaximumSize = new System.Drawing.Size(0, 40);
            customButtonOtm.Name = "customButtonOtm";
            customButtonOtm.Size = new System.Drawing.Size(75, 22);
            customButtonOtm.TabIndex = 25;
            customButtonOtm.Text = "Отмена";
            customButtonOtm.UseVisualStyleBackColor = false;
            customButtonOtm.Click += customButtonOtm_Click;
            // 
            // customButtonSave
            // 
            customButtonSave.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            customButtonSave.Dock = System.Windows.Forms.DockStyle.Fill;
            customButtonSave.Font = new System.Drawing.Font("Arial", 10F);
            customButtonSave.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customButtonSave.Location = new System.Drawing.Point(84, 286);
            customButtonSave.MaximumSize = new System.Drawing.Size(0, 40);
            customButtonSave.Name = "customButtonSave";
            customButtonSave.Size = new System.Drawing.Size(185, 22);
            customButtonSave.TabIndex = 24;
            customButtonSave.Text = "Сохранить";
            customButtonSave.UseVisualStyleBackColor = false;
            customButtonSave.Click += customButtonSave_Click;
            // 
            // customComboBoxType
            // 
            customComboBoxType.BackColor = System.Drawing.Color.FromArgb(245, 245, 250);
            customComboBoxType.Dock = System.Windows.Forms.DockStyle.Fill;
            customComboBoxType.Font = new System.Drawing.Font("Arial", 10F);
            customComboBoxType.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customComboBoxType.FormattingEnabled = true;
            customComboBoxType.Location = new System.Drawing.Point(84, 147);
            customComboBoxType.Name = "customComboBoxType";
            customComboBoxType.Size = new System.Drawing.Size(185, 24);
            customComboBoxType.TabIndex = 42;
            // 
            // customDateTimePickerBegin
            // 
            customDateTimePickerBegin.BackColor = System.Drawing.Color.FromArgb(245, 245, 250);
            customDateTimePickerBegin.Font = new System.Drawing.Font("Arial", 10F);
            customDateTimePickerBegin.ForeColor = System.Drawing.Color.FromArgb(85, 45, 115);
            customDateTimePickerBegin.Location = new System.Drawing.Point(84, 177);
            customDateTimePickerBegin.Name = "customDateTimePickerBegin";
            customDateTimePickerBegin.ObjectName = null;
            customDateTimePickerBegin.Size = new System.Drawing.Size(185, 23);
            customDateTimePickerBegin.TabIndex = 44;
            // 
            // customButtonAdd
            // 
            customButtonAdd.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            customButtonAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            customButtonAdd.Font = new System.Drawing.Font("Arial", 10F);
            customButtonAdd.ForeColor = System.Drawing.Color.FromArgb(72, 61, 139);
            customButtonAdd.Location = new System.Drawing.Point(838, 34);
            customButtonAdd.MaximumSize = new System.Drawing.Size(0, 40);
            customButtonAdd.Name = "customButtonAdd";
            customButtonAdd.Size = new System.Drawing.Size(136, 29);
            customButtonAdd.TabIndex = 6;
            customButtonAdd.Text = "Добавить";
            customButtonAdd.UseVisualStyleBackColor = false;
            customButtonAdd.Click += customButtonAdd_Click;
            // 
            // customGridControlHistory
            // 
            customGridControlHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            customGridControlHistory.Font = new System.Drawing.Font("Arial", 10F);
            customGridControlHistory.Location = new System.Drawing.Point(3, 441);
            customGridControlHistory.MainView = gridViewHistory;
            customGridControlHistory.Name = "customGridControlHistory";
            customGridControlHistory.Size = new System.Drawing.Size(554, 194);
            customGridControlHistory.TabIndex = 7;
            customGridControlHistory.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridViewHistory });
            // 
            // gridViewHistory
            // 
            gridViewHistory.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            gridViewHistory.Appearance.EvenRow.Options.UseBackColor = true;
            gridViewHistory.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            gridViewHistory.Appearance.FocusedRow.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            gridViewHistory.Appearance.FocusedRow.Options.UseBackColor = true;
            gridViewHistory.Appearance.FocusedRow.Options.UseFont = true;
            gridViewHistory.GridControl = customGridControlHistory;
            gridViewHistory.Name = "gridViewHistory";
            gridViewHistory.OptionsView.EnableAppearanceEvenRow = true;
            // 
            // customGridControlTR
            // 
            tableLayoutPanel1.SetColumnSpan(customGridControlTR, 3);
            customGridControlTR.Dock = System.Windows.Forms.DockStyle.Fill;
            customGridControlTR.Font = new System.Drawing.Font("Arial", 10F);
            customGridControlTR.Location = new System.Drawing.Point(563, 441);
            customGridControlTR.MainView = gridViewTR;
            customGridControlTR.Name = "customGridControlTR";
            customGridControlTR.Size = new System.Drawing.Size(553, 194);
            customGridControlTR.TabIndex = 8;
            customGridControlTR.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridViewTR });
            customGridControlTR.Load += customGridControlTR_Load;
            // 
            // gridViewTR
            // 
            gridViewTR.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            gridViewTR.Appearance.EvenRow.Options.UseBackColor = true;
            gridViewTR.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(230, 230, 250);
            gridViewTR.Appearance.FocusedRow.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            gridViewTR.Appearance.FocusedRow.Options.UseBackColor = true;
            gridViewTR.Appearance.FocusedRow.Options.UseFont = true;
            gridViewTR.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] { id_kod_o, prizn_podr, tarif, ed_izm, koef_chas, razr, Text });
            gridViewTR.GridControl = customGridControlTR;
            gridViewTR.Name = "gridViewTR";
            gridViewTR.OptionsView.EnableAppearanceEvenRow = true;
            // 
            // id_kod_o
            // 
            id_kod_o.Caption = "id";
            id_kod_o.FieldName = "id_kod_o";
            id_kod_o.Name = "id_kod_o";
            id_kod_o.Visible = true;
            id_kod_o.VisibleIndex = 0;
            id_kod_o.Width = 23;
            // 
            // prizn_podr
            // 
            prizn_podr.Caption = "Призн. Подр.";
            prizn_podr.FieldName = "prizn_podr";
            prizn_podr.Name = "prizn_podr";
            prizn_podr.Visible = true;
            prizn_podr.VisibleIndex = 2;
            prizn_podr.Width = 81;
            // 
            // tarif
            // 
            tarif.Caption = "Тариф";
            tarif.FieldName = "tarif";
            tarif.Name = "tarif";
            tarif.Visible = true;
            tarif.VisibleIndex = 3;
            tarif.Width = 117;
            // 
            // ed_izm
            // 
            ed_izm.Caption = "ед. изм.";
            ed_izm.FieldName = "ed_izm";
            ed_izm.Name = "ed_izm";
            ed_izm.Visible = true;
            ed_izm.VisibleIndex = 4;
            ed_izm.Width = 61;
            // 
            // koef_chas
            // 
            koef_chas.Caption = "Коэф.";
            koef_chas.FieldName = "koef_chas";
            koef_chas.Name = "koef_chas";
            koef_chas.Visible = true;
            koef_chas.VisibleIndex = 5;
            koef_chas.Width = 69;
            // 
            // razr
            // 
            razr.Caption = "Разр.";
            razr.FieldName = "razr";
            razr.Name = "razr";
            razr.Visible = true;
            razr.VisibleIndex = 6;
            razr.Width = 54;
            // 
            // Text
            // 
            Text.Caption = "Название";
            Text.FieldName = "Text";
            Text.Name = "Text";
            Text.Visible = true;
            Text.VisibleIndex = 1;
            Text.Width = 330;
            // 
            // xtraTabPageTarif
            // 
            xtraTabPageTarif.Name = "xtraTabPageTarif";
            xtraTabPageTarif.Size = new System.Drawing.Size(1119, 638);
            xtraTabPageTarif.Text = "Тарифы";
            // 
            // Название
            // 
            Название.Caption = "text";
            Название.Name = "Название";
            Название.Visible = true;
            Название.VisibleIndex = 1;
            // 
            // EditTarif
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1121, 663);
            Controls.Add(customTabControlZpTarif);
            Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
            Name = "EditTarif";
            ((System.ComponentModel.ISupportInitialize)customTabControlZpTarif).EndInit();
            customTabControlZpTarif.ResumeLayout(false);
            xtraTabPageZP.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            customGroupBoxFiltr.ResumeLayout(false);
            customGroupBoxFiltr.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)customGridControlZp).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridViewZp).EndInit();
            customGroupBoxAdd.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)customGridControlHistory).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridViewHistory).EndInit();
            ((System.ComponentModel.ISupportInitialize)customGridControlTR).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridViewTR).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private CustomTabControl customTabControlZpTarif;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageZP;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageTarif;
        private CustomRadioButton customRadioButtonAceKle;
        private Core.Class.CustomGridControl customGridControlZp;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewZp;
        private CustomGroupBox customGroupBoxFiltr;
        private CustomRadioButton customRadioButtonAll;
        private CustomRadioButton customRadioButtonExp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private CustomTextBox customTextBoxRazm;
        private Core.Class.CustomButton customButtonOtm;
        private CustomTextBox customTextBoxZnach;
        private Core.Class.CustomButton customButtonSave;
        private CustomGroupBox customGroupBoxAdd;
        private CustomComboBox customComboBoxOrg;
        private CustomTextBox customTextBoxOpis;
        private CustomLabel customLabelNull;
        private CustomLabel customLabelOrg;
        private CustomLabel customLabelZnach;
        private CustomLabel customLabelDate;
        private CustomLabel customLabelType;
        private CustomLabel customLabelOpis;
        private CustomLabel customLabelRazm;
        private CustomTextBox customTextBoxName;
        private CustomLabel customLabelName;
        private CustomCheckBox customCheckBoxNotRazm;
        private CustomComboBox customComboBoxType;
        private Core.Class.CustomButton customButtonAdd;
        private Core.Class.CustomGridControl customGridControlHistory;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewHistory;
        private DevExpress.XtraGrid.Columns.GridColumn describe;
        private DevExpress.XtraGrid.Columns.GridColumn begin_dt;
        private DevExpress.XtraGrid.Columns.GridColumn value_numeric;
        private DevExpress.XtraGrid.Columns.GridColumn value_datetime;
        private DevExpress.XtraGrid.Columns.GridColumn value_integer;
        private DevExpress.XtraGrid.Columns.GridColumn value_float;
        private DevExpress.XtraGrid.Columns.GridColumn value_character;
        private DevExpress.XtraGrid.Columns.GridColumn firm;
        private DevExpress.XtraGrid.Columns.GridColumn Название;
        private CustomRadioButton customRadioButtonMay;
        private Core.Class.CustomGridControl customGridControlTR;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewTR;
        private DevExpress.XtraGrid.Columns.GridColumn id_kod_o;
        private DevExpress.XtraGrid.Columns.GridColumn prizn_podr;
        private DevExpress.XtraGrid.Columns.GridColumn tarif;
        private DevExpress.XtraGrid.Columns.GridColumn ed_izm;
        private DevExpress.XtraGrid.Columns.GridColumn koef_chas;
        private DevExpress.XtraGrid.Columns.GridColumn razr;
        private DevExpress.XtraGrid.Columns.GridColumn Text;
        private CustomDateTimePicker customDateTimePickerBegin;
    }
}