﻿using System.Threading.Tasks;
using System.Threading;
using System;
using SewingProduction.Models;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid;
using SewingProduction.Helpers;
using System.Collections.Generic;
using System.Drawing;
using DevExpress.XtraGrid.Views.Base;
using System.Collections;
using SewingProduction.Services;
using DevExpress.Xpo.DB.Helpers;
using System.Linq;

namespace SewingProduction.Forms
{
    public partial class TeamWork
    {
        // Вторая вкладка — "Работа с артикулами"

        private bool _isUnchecking = false;

        /// <summary>
        /// Загрузка вкладки "текущие работы" (MyDataAnn)
        /// </summary>
        private async Task CurrentWorks_Load()
        {

            // Отписываемся от событий ПЕРЕД загрузкой
            if (this.gridView_unboundArts != null)
            {
                this.gridView_unboundArts.FocusedRowChanged -= gridView_unboundArts_FocusedRowChanged;
            }
            if (this.gridView_wdToBind != null)
            {
                this.gridView_wdToBind.FocusedRowChanged -= gridViewWdToBind_FocusedRowChanged;
            }

            try
            {
                Task preArchTask = PreArchLoad();

                // Загружаем основные данные
                await MyDataArtLoad();
                await MyDataAnnLoad();

                await preArchTask;

                TWGridHelper.sortGridView(gridView6);
                //TWGridHelper.sortGridView(gridViewRaskr);
                //TWGridHelper.sortGridView(gridViewKont);


                // Load NormRasz data for the Articles tab using the dedicated BindingList and BindingSource
                if (this.gridView_wdToBind != null && gridView_wdToBind.RowCount > 0 && gridView_wdToBind.FocusedRowHandle >= 0)
                {
                    int initialAnnId = CommonFunctions.GetRowCellValueOrDefault<int>(gridView_wdToBind, gridView_wdToBind.FocusedRowHandle, "AnnId", 0);
                    List<NormRasz> raszData = new List<NormRasz>();
                    if (initialAnnId > 0)
                    {
                        raszData = await _artNormService.GetRelatedNormRasz(initialAnnId);
                    }

                    _normRaszListArticles.Clear();
                    if (raszData != null)
                    {
                        foreach (var item in raszData)
                        {
                            _normRaszListArticles.Add(item);
                        }
                    }
                    _normRaszBindingSourceArticles.ResetBindings(false);
                }
                else
                {
                    _normRaszListArticles.Clear();
                    _normRaszBindingSourceArticles.ResetBindings(false);
                }
            }
            finally
            {
                // Подписываемся обратно ПОСЛЕ всей загрузки
                if (this.gridView_unboundArts != null)
                {
                    this.gridView_unboundArts.FocusedRowChanged += gridView_unboundArts_FocusedRowChanged;
                }
                if (this.gridView_wdToBind != null)
                {
                    this.gridView_wdToBind.FocusedRowChanged += gridViewWdToBind_FocusedRowChanged;
                }
            }
        }


        private async Task MyDataArtLoad()
        {
            try
            {
                // Проверяем, инициализирован ли список/источник (должны быть в TeamWork.cs)
                if (_myDataArtList == null || _myDataArtBindingSource == null)
                {
                    await _logger.LogErrorAsync(new NullReferenceException("_myDataArtList or _myDataArtBindingSource is null"), "MyDataArtLoad initialization check failed.");
                    MessageBox.Show("Ошибка инициализации списка артикулов.", "Критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string query = "SELECT DISTINCT SUBSTRING(sa.kod,1,7) as kod, sa.grup, sa.articul, sa.mod, sa.annId " +
                    "FROM sp_articul sa " +
                    "   left join kompl k on sa.kod = k.kod_k " +
                    "WHERE sa.annID IS NULL and k.kod_k is null";
                List<MyDataART> loadedData = await _dbService.GetListAsync<MyDataART>(query, null);

                //_myDataArtList.Clear(); // Очищаем BindingList

                //if (loadedData != null)
                //{
                //    foreach (var item in loadedData)
                //    {
                //        _myDataArtList.Add(item); // Добавляем элементы в BindingList
                //    }
                //}

                //_myDataArtBindingSource.ResetBindings(false); // Уведомляем BindingSource (и грид) об изменениях
                _myDataArtList.BulkLoad(loadedData);

                await _logger.LogEventAsync($"Загружено {_myDataArtList.Count} записей MyDataART.", "MyDataArtLoad");
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, $"Ошибка загрузки данных MyDataART: {ex.Message}");
                // Отображаем сообщение только если инициализация прошла успешно
                if (_myDataArtList != null && _myDataArtBindingSource != null)
                {
                    MessageBox.Show($"Ошибка загрузки данных артикулов: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async Task MyDataAnnLoad()
        {
            try
            {
                // Проверяем, инициализирован ли список/источник (должны быть в TeamWork.cs)
                if (_myDataAnnList == null || _myDataAnnBindingSource == null)
                {
                    await _logger.LogErrorAsync(new NullReferenceException("_myDataAnnList or _myDataAnnBindingSource is null"), "MyDataAnnLoad initialization check failed.");
                    MessageBox.Show("Ошибка инициализации списка РТ.", "Критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int kod = GetCurrentKodFromDataSource();
                List<MyDataANN> loadedData = await _artNormService.GetArtNormDataCurrent(kod, loadAllCheckBox.Checked);

                //_myDataAnnList.Clear(); // Очищаем BindingList

                //if (loadedData != null && loadedData.Count > 0)
                //{
                //    foreach (var item in loadedData)
                //    {
                //        _myDataAnnList.Add(item); // Добавляем элементы в BindingList
                //    }
                //    await _logger.LogEventAsync($"Загружено {_myDataAnnList.Count} записей MyDataANN (kod: {kod}, loadAll: {loadAllCheckBox.Checked}).", "MyDataAnnLoad");
                //}
                //else
                //{
                //    // Логгируем, если данных нет, вместо MessageBox
                //    await _logger.LogEventAsync($"Нет данных MyDataANN для загрузки (kod: {kod}, loadAll: {loadAllCheckBox.Checked})", "MyDataAnnLoad");
                //}
                _myDataAnnList.BulkLoad(loadedData);

               // _myDataAnnBindingSource.ResetBindings(false); // Уведомляем BindingSource (и грид) об изменениях
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, $"Ошибка загрузки данных MyDataANN: {ex.Message}");
                // Отображаем сообщение только если инициализация прошла успешно
                if (_myDataAnnList != null && _myDataAnnBindingSource != null)
                {
                    MessageBox.Show($"Ошибка загрузки данных РТ: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Получает значение Kod из текущего элемента источника данных _myDataArtBindingSource.
        /// </summary>
        /// <returns>Значение Kod или 0, если текущий элемент не найден или Kod не может быть преобразован в число.</returns>
        private int GetCurrentKodFromDataSource()
        {
            if (_myDataArtBindingSource != null && _myDataArtBindingSource.Current != null)
            {
                var currentItem = _myDataArtBindingSource.Current as MyDataART;
                if (currentItem != null)
                {
                    if (int.TryParse(currentItem.Kod, out int kodValue))
                    {
                        return kodValue;
                    }
                    else
                    {
                        _logger.LogEventAsync($"Не удалось преобразовать Kod '{currentItem.Kod}' в число.", "GetCurrentKodFromDataSource").ConfigureAwait(false);
                    }
                }
            }
            return 0;
        }

        /// <summary>
        /// Загружает список разделений труда (РТ) для указанного артикула или кода.
        /// </summary>
        /// <param name="kod">Код артикула</param>
        /// <param name="articul">Название артикула</param>
        /// <returns>Список разделений труда (BindingList&lt;MyDataANN&gt;)</returns>
        private async Task<List<MyDataANN>> LoadWorksbyArt(int kod, string articul)
        {
            try
            {
                List<MyDataANN> relatedData = new List<MyDataANN>();
                bool loadAll = loadAllCheckBox.Checked;

                // Если включен чекбокс "Загрузить все"
                if (loadAll)
                {
                    return await _artNormService.GetArtNormDataCurrent(kod, true);
                }

                // Загружаем все данные параллельно
                var tasks = new List<Task<List<MyDataANN>>>();

                // Загружаем данные по коду
                tasks.Add(_artNormService.GetArtNormDataCurrent(kod, false));

                // Если артикул не пустой, добавляем задачи для поиска по артикулу
                if (!string.IsNullOrEmpty(articul))
                {
                    // Ищем по полному артикулу
                    tasks.Add(_artNormService.GetArtNormDataByArticul(articul));

                    // Ищем по артикулу без дефиса
                    string artWithoutDash = articul.Replace("-", "");
                    if (artWithoutDash != articul)
                    {
                        tasks.Add(_artNormService.GetArtNormDataByArticul(artWithoutDash));
                    }

                    // Если артикул содержит дефис, ищем по его первой части
                    int dashIndex = articul.IndexOf("-");
                    if (dashIndex > 0)
                    {
                        string artPrefix = articul.Substring(0, dashIndex);
                        tasks.Add(_artNormService.GetArtNormDataByArticul(artPrefix));
                    }
                }

                // Ждем завершения всех задач
                var results = await Task.WhenAll(tasks);

                // Объединяем результаты
                foreach (var result in results)
                {
                    if (result != null)
                    {
                        relatedData.AddRange(result);
                    }
                }

                // Удаляем дубликаты по AnnId используя Dictionary для быстрого поиска
                var uniqueData = new Dictionary<int, MyDataANN>();
                foreach (var item in relatedData)
                {
                    if (!uniqueData.ContainsKey(item.AnnID))
                    {
                        uniqueData[item.AnnID] = item;
                    }
                }

                await _logger.LogEventAsync($"Успешная загрузка РТ для кода {kod} и артикула {articul}", "LoadWorksbyArt");
                return uniqueData.Values.ToList();
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, $"Ошибка при загрузке РТ для кода {kod} и артикула {articul}");
                return new List<MyDataANN>();
            }
        }


        /// <summary>
        /// Обрабатывает событие смены строки в РТ для увязки(вкладка артикулы)
        /// загрузка norm_rasz и связанных данных (НЗП, картинка).
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void gridViewWdToBind_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            var view = sender as GridView;// gridView_wdToBind; 
            if (view == null) return;

            // Отменяем предыдущие операции загрузки для Articles tab
            var oldCts = Interlocked.Exchange(ref _loadCts, new CancellationTokenSource());
            oldCts?.Cancel();
            oldCts?.Dispose();
            var token = _loadCts.Token;

            try
            {
                int annId = CommonFunctions.GetRowCellValueOrDefault<int>(view, e.FocusedRowHandle, "AnnID", 0);

                //1.Сначала загружаем изображение(быстрая операция)
                if (annId >0)
                {
                        LoadGridImage(pictureBox2, annId: annId);
                }
                else
                {
                    //await _logger.LogWarningAsync($"Значение Kod пустое или null для строки {e.FocusedRowHandle}.", "gridViewWdToBind_FocusedRowChanged");
                }

                // 2. Затем загружаем основные данные
                token.ThrowIfCancellationRequested();
                
                // Обновляем NormRasz для customGridControl3
                await RefreshNormRaszForArticlesTab(annId, token);

                // 3. Загрузка данных НЗП только для выбранной строки
                token.ThrowIfCancellationRequested();
                await LoadNZPForArticlesTab(annId, token);
            }
            catch (OperationCanceledException)
            {
                // Тихо игнорируем отмену операции
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, $"Ошибка при смене выбранной строки в gridViewWdToBind (RowHandle: {e.FocusedRowHandle})");
            }
        }

        /// <summary>
        /// Загружает и обновляет NormRasz данные для вкладки "Артикулы" (customGridControl3).
        /// </summary>
        /// <param name="annId">AnnID для загрузки NormRasz.</param>
        /// <param name="cancellationToken">Токен отмены операции.</param>
        private async Task RefreshNormRaszForArticlesTab(int annId, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            List<NormRasz> raszList = new List<NormRasz>();
            if (annId > 0)
            {
                raszList = await _artNormService.GetRelatedNormRasz(annId);
                cancellationToken.ThrowIfCancellationRequested();
            }

            _normRaszListArticles.RaiseListChangedEvents = false;
            _normRaszListArticles.Clear();
            if (raszList != null)
            {
                foreach (var item in raszList)
                {
                    _normRaszListArticles.Add(item);
                }
            }
            _normRaszListArticles.RaiseListChangedEvents = true;
            _normRaszBindingSourceArticles.ResetBindings(false);
        }

        /// <summary>
        /// Загружает данные НЗП для вкладки "Артикулы".
        /// </summary>
        /// <param name="annId">AnnID для загрузки НЗП.</param>
        /// <param name="cancellationToken">Токен отмены операции.</param>
        private async Task LoadNZPForArticlesTab(int annId, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            var nzpData = annId > 0 ? await _artNormService.GetNzpWithPztCounts(annId, cancellationToken) : new List<NZPByKoddRt>();
            
            cancellationToken.ThrowIfCancellationRequested();
            
            _nzpListArt.RaiseListChangedEvents = false;
            _nzpListArt.Clear();
            foreach (var item in nzpData)
            {
                _nzpListArt.Add(item);
            }
            _nzpListArt.RaiseListChangedEvents = true;
            
            _nzpByKoddRtSourceArt?.ResetBindings(false);
            gridControlNZP?.RefreshDataSource(); // Обновить грид НЗП
            await UpdateUnboundButtonStatusBasedOnNZP(); // Обновить состояние кнопки
        }

        private async Task PreArchLoad()
        {
            try
            {
                string query = "SELECT * FROM artNormNView WHERE status = 4";
                List<MyDataANN> preArchData = await _dbService.GetListAsync<MyDataANN>(query, null);

                if (_preArchList == null || _preArchBindingSource == null)
                {
                    await _logger.LogErrorAsync(new NullReferenceException("_preArchList or _preArchBindingSource is null"), "PreArchLoad failed initialization check.");
                    MessageBox.Show("Ошибка инициализации списка предварительного архива.", "Критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                //_preArchList.Clear();

                //if (preArchData != null)
                //{
                //    foreach (var item in preArchData)
                //    {
                //        _preArchList.Add(item);
                //    }
                //}
                //_preArchBindingSource.ResetBindings(false);
                _preArchList.BulkLoad(preArchData);

                await _logger.LogEventAsync($"Загружено {_preArchList.Count} записей в предварительный архив.", "PreArchLoad");

            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, $"Ошибка загрузки данных в предварительный архив: {ex.Message}");
                if (_preArchList != null && _preArchBindingSource != null)
                {
                    MessageBox.Show($"Ошибка загрузки данных предварительного архива: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Привязывает выбранные артикулы к выбранному разделению труда (РТ).
        /// </summary>
        private async Task BindButton_Click_Internal(object sender, EventArgs e)
        {
            gridView_unboundArts.CloseEditor();
            gridView_unboundArts.UpdateCurrentRow();
            gridView_wdToBind.CloseEditor();
            gridView_wdToBind.UpdateCurrentRow();
            try
            {
                GridView artView = gridView_unboundArts;
                GridView annView = gridView_wdToBind;

                if (artView == null || annView == null)
                {
                    MessageBox.Show("Данные не загружены!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                MyDataART selectedArtRow = null;
                MyDataANN selectedAnnRow = null;
                // Получаем датасорсы
                var artBindingSource = artView.DataSource as BindingSource;
                var artDataSource = artBindingSource?.DataSource as BindingList<MyDataART>;

                //// Получаем выбранное разделение труда
                var annBindingSource = _myDataAnnBindingSource;
                var annDataSource = annBindingSource?.DataSource as BindingList<MyDataANN>;
                selectedArtRow = artDataSource?.FirstOrDefault(r => r.IsChecked);
                selectedAnnRow = annDataSource?.FirstOrDefault(r => r.IsChecked);

                // Проверяем, выбраны ли оба элемента
                if (selectedArtRow is null || selectedAnnRow is null)
                {
                    MessageBox.Show("Выберите артикул и разделение труда для привязки!", "Внимание!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                DialogResult result = MessageBox.Show(
                    $"Вы действительно хотите привязать артикул {selectedArtRow.Articul.TrimEnd()} к разделению труда {selectedAnnRow.Articul.TrimEnd()}?",
                    "Подтверждение привязки",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (result == DialogResult.No) return;


                // Обновляем annId в базе данных
                _artNormService.UpdateAnnIdinArticul(selectedArtRow.Kod, selectedAnnRow.AnnID);
                selectedArtRow.BindedArt = selectedAnnRow.Articul;//заполняем в артикуле из РТ
                if (string.IsNullOrEmpty(selectedAnnRow.grup))
                {
                    selectedAnnRow.grup = selectedArtRow.grup;
                }
                if (string.IsNullOrEmpty(selectedAnnRow.mod))
                {
                    selectedAnnRow.mod = selectedArtRow.mod;
                }
                // await _dbService.UpdateFieldAsync(TableNames.Art, "annId", selectedAnnRow.AnnID, "kod", selectedArtRow.Kod);//хочу поменять обновление annId в артикуле, но пока не могу
                await _dbService.UpdateEntityAsync(TableNames.Ann, TableNames.AnnId, selectedAnnRow);
                // Обновляем UI:
                if (artDataSource != null && selectedArtRow != null)
                {
                    // 0. Присваиваем привязанному артикулу артикул разделений
                    selectedArtRow.BindedArt = selectedAnnRow.Articul;
                    // 1. Добавляем привязанный артикул в список для gridView1
                    _boundArtList?.Add(selectedArtRow);

                    // 2. Удаляем артикул из списка доступных для gridView7
                    artDataSource.Remove(selectedArtRow);
                }
                else
                {
                    artView.RefreshData();
                    annView.RefreshData();
                    // Обновим и gridView12 на всякий случай
                    gridControl_binded?.RefreshDataSource();
                    gridControl_wdToBind?.RefreshDataSource();
                }

                await _logger.LogEventAsync("Привязка завершена", $"Артикул {selectedArtRow.Kod} привязан к РТ {selectedAnnRow.AnnID}");
                MessageBox.Show("Привязка успешно выполнена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, "Ошибка при привязке артикула к РТ");
                MessageBox.Show($"Ошибка при привязке артикула: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обрабатывает смену строки в таблице неувязанных артикулов
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void gridView_unboundArts_FocusedRowChanged_Internal(object sender, FocusedRowChangedEventArgs e)
        {
            var gv_unbound_Arts = sender as GridView;
            if (gv_unbound_Arts == null || e.FocusedRowHandle < 0) return;

            try
            {
                // Получаем данные из текущей строки
                string kod = CommonFunctions.GetRowCellValueOrDefault<string>(gv_unbound_Arts, e.FocusedRowHandle, "Kod", "");
                string articul = CommonFunctions.GetRowCellValueOrDefault<string>(gv_unbound_Arts, e.FocusedRowHandle, "Articul", "");

                if (!int.TryParse(kod, out int kodInt))
                {
                    await _logger.LogWarningAsync($"Не удалось преобразовать Kod '{kod}' в число", "gridView_unboundArts_FocusedRowChanged_Internal");
                    return;
                }

                // Загружаем данные параллельно
                var loadWorksTask = LoadWorksbyArt(kodInt, articul);
                var loadRaszTask = Task.Run(async () =>
                {
                    if (gridView_wdToBind.FocusedRowHandle >= 0)
                    {
                        int annId = CommonFunctions.GetRowCellValueOrDefault<int>(gridView_wdToBind, gridView_wdToBind.FocusedRowHandle, "AnnId", 0);
                        return annId > 0 ? await _artNormService.GetRelatedNormRasz(annId) : new List<NormRasz>();
                    }
                    return new List<NormRasz>();
                });

                // Ждем загрузку данных
                var list = await loadWorksTask;

                // Обновляем основной список данных
                if (_myDataAnnBindingSource != null)
                {
                    _myDataAnnList.Clear();
                    if (list != null && list.Count > 0)
                    {
                        // Отключаем уведомления на время добавления элементов
                        _myDataAnnList.RaiseListChangedEvents = false;
                        try
                        {
                            foreach (var item in list)
                            {
                                _myDataAnnList.Add(item);
                            }
                        }
                        finally
                        {
                            // Включаем уведомления обратно
                            _myDataAnnList.RaiseListChangedEvents = true;
                        }
                    }
                    _myDataAnnBindingSource.ResetBindings(false);
                }
                else
                {
                    gridControl_wdToBind.DataSource = list;
                }

                // Обновляем UI один раз после всех изменений данных
                gridView_wdToBind.RefreshData();
                gridControl_wdToBind.RefreshDataSource();

                // Обновляем customGridControl3 using _normRaszListArticles and _normRaszBindingSourceArticles
                var raszList = await loadRaszTask;
                _normRaszListArticles.Clear();
                if (raszList != null)
                {
                    foreach (var item in raszList)
                    {
                        _normRaszListArticles.Add(item);
                    }
                }
                _normRaszBindingSourceArticles.ResetBindings(false);

                // Загружаем изображение, если есть код
                if (kodInt > 0)
                {
                    await Task.Run(() => LoadGridImage(pictureBox3, kod: kodInt));
                }
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, "Ошибка в gridView_unboundArts_FocusedRowChanged_Internal");
                // В случае ошибки очищаем данные
                if (_myDataAnnBindingSource != null)
                {
                    _myDataAnnList.Clear();
                    _myDataAnnBindingSource.ResetBindings(false);
                }
                gridView_wdToBind.RefreshData();
                gridControl_wdToBind.RefreshDataSource();
                _normRaszListArticles.Clear(); // Clear in case of error
                _normRaszBindingSourceArticles.ResetBindings(false);
            }
        }
    }
}

