﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using SewingProduction.Extensions;
using SewingProduction.Interfaces;

namespace SewingProduction.Helpers
{
    public class TWGridHelper
    {
        public static readonly FileLogger _logger = new FileLogger();
        #region async
        /// <summary>
        /// Загружает данные в `GridControl` через `BindingSource` асинхронно.
        /// </summary>
        /// <param name="grid">GridControl, в который загружаются данные</param>
        /// <param name="source">BindingSource для привязки данных</param>
        /// <param name="data">DataTable с данными</param>
        public static async Task LoadGridControlDataAsync<T>(GridControl grid, BindingSource source, List<T> data)
        {
            await Task.Run(() =>
            {
                grid.Invoke((MethodInvoker)(() =>
                {
                    source.DataSource = data;
                    source.ResetBindings(false);
                    grid.DataSource = source;
                    grid.RefreshDataSource();
                }));
            });
        }

        //public static async Task LoadListDataAsync(List<MyDataART> list, BindingSource source, List<MyDataART> data)
        //{
        //    await Task.Run(() =>
        //    {
        //        source.DataSource = data;
        //    });

        //    if (source.CurrencyManager?.Current is Control control && control.InvokeRequired)
        //    {
        //        control.Invoke((MethodInvoker)(() =>
        //        {
        //            source.ResetBindings(false);
        //        }));
        //    }
        //    else
        //    {
        //        source.ResetBindings(false);
        //    }
        //}

        public static async Task LoadListDataAsync<T>(GridControl grid, BindingSource source, List<T> dataList)
        {
            if (grid.InvokeRequired)
            {
                // Мы не в UI-потоке → оборачиваем всё в Invoke
                await grid.InvokeAsync(() =>
                {
                    source.DataSource = dataList;
                    grid.DataSource = source;
                    grid.RefreshDataSource();
                });
            }
            else
            {
                // Уже в UI-потоке
                source.DataSource = dataList;
                grid.DataSource = source;
                grid.RefreshDataSource();
            }
        }

        /// <summary>
        /// Применяет фильтр к `GridControl` асинхронно.
        /// </summary>
        /// <param name="grid">GridControl, который нужно отфильтровать</param>
        /// <param name="annId">Идентификатор разделения труда</param>
        public static async Task ApplyFilterAsync(GridControl grid, int annId)
        {
            await Task.Run(() =>
            {
                string filter = "annId = " + annId;
                GridView view = (GridView)grid.Views[0];

                view.BeginUpdate();
                view.ActiveFilterString = filter;
                view.EndUpdate();
            });
        }

        /// <summary>
        /// Загружает изображение в `PictureBox` по `annId` асинхронно.
        /// </summary>
        /// <param name="pictureBox">PictureBox для загрузки изображения</param>
        /// <param name="data">DataTable с путем к изображению</param>
        public static async Task LoadImageAsync(PictureBox pictureBox, DataTable data)
        {
            await Task.Run(() =>
            {
                if (data != null && data.Rows.Count > 0)
                {
                    pictureBox.Invoke((MethodInvoker)(() =>
                    {
                        pictureBox.ImageLocation = data.Rows[0]["pathpict"].ToString();
                    }));
                }
            });
        }


        /// <summary>
        /// Возвращает имя выбранного столбца для поиска.
        /// </summary>
        public static Task<string> GetSelectedColumnNameAsync(bool kode, bool articul, bool model, bool group)
        {
            return Task.FromResult(
                kode ? "Kod" :
                articul ? "Articul" :
                model ? "Mod" :
                group ? "Group" :
                string.Empty);
        }
        /// <summary>
        /// Проверяет, загружены ли данные в GridView.
        /// </summary>
        /// <param name="view">GridView для проверки</param>
        /// <returns>True, если данные загружены</returns>
        public static Task<bool> IsDataTableLoadedAsync(GridView view)
        {
            return Task.FromResult(view.DataSource is BindingSource bindingSource &&
                                   bindingSource.DataSource is DataTable dataTable &&
                                   dataTable.Rows.Count > 0);
        }
        /// <summary>
        /// Асинхронно снимает выделение всех строк, кроме текущей.
        /// </summary>
        public static async Task UpdateExclusiveCheckAsync<T>(GridControl grid, int rowHandle) where T : class
        {
            GridView gridView = grid.MainView as GridView;
            if (grid.InvokeRequired)
            {
                grid.Invoke(new MethodInvoker(async () => await UpdateExclusiveCheckAsync<T>(grid, rowHandle)));
                return;
            }

            await Task.Run(() =>
            {
                var selectedData = gridView.GetRow(rowHandle) as T;
                if (selectedData is ICheckable checkableSelectedData)
                {
                    checkableSelectedData.IsChecked = true;

                    for (int i = 0; i < gridView.RowCount; i++)
                    {
                        if (i != rowHandle)
                        {
                            var otherData = gridView.GetRow(i) as T;
                            if (otherData is ICheckable checkableOtherData && checkableOtherData.IsChecked)
                            {
                                checkableOtherData.IsChecked = false;
                            }
                        }
                    }
                }
                gridView.RefreshData();
            });
        }
        #endregion

        #region GridColumnSettings
        // Сохранение настроек грида
        //public void SaveGridViewSettings(GridView gridView, string fileName)
        //{
        //    try
        //    {
        //        string appPath = System.Windows.Forms.Application.StartupPath;
        //        string settingsPath = Path.Combine(appPath, "Settings");

        //        // Create directory if it doesn't exist
        //        if (!Directory.Exists(settingsPath))
        //            Directory.CreateDirectory(settingsPath);

        //        string fullPath = Path.Combine(settingsPath, fileName);

        //        // Create XML document with column settings
        //        //using (XmlWriter writer = XmlWriter.Create(fullPath))
        //        //{
        //        //    writer.WriteStartDocument();
        //        //    writer.WriteStartElement("GridViewLayout");

        //        //    writer.WriteStartElement("Columns");
        //        //    foreach (GridColumn column in gridView.Columns)
        //        //    {
        //        //        writer.WriteStartElement("Column");
        //        //        writer.WriteAttributeString("FieldName", column.FieldName);
        //        //        writer.WriteAttributeString("Width", column.Width.ToString());
        //        //        writer.WriteAttributeString("VisibleIndex", column.VisibleIndex.ToString());
        //        //        writer.WriteAttributeString("Visible", column.Visible.ToString());
        //        //        writer.WriteEndElement(); // Column
        //        //    }
        //        //    writer.WriteEndElement(); // Columns

        //        //    writer.WriteEndElement(); // GridViewLayout
        //        //    writer.WriteEndDocument();
        //        //}
        //        // Сохраняем текущие настройки: запоминаем опции для сохранения внешнего вида и настроек данных
        //        var storeAppearance = gridView.OptionsLayout.StoreAppearance;
        //        var storeDataSettings = gridView.OptionsLayout.StoreDataSettings;

        //        // Отключаем сохранение фильтров и поиска, чтобы не сохранить ненужные данные
        //        gridView.OptionsLayout.StoreAppearance = false;
        //        gridView.OptionsLayout.StoreDataSettings = false;

        //        // Сохраняем текущий текст поиска, чтобы потом его восстановить
        //        var findFilterText = gridView.FindFilterText;
        //        gridView.FindFilterText = string.Empty;

        //        // Сохраняем макет грида в XML
        //        gridView.SaveLayoutToXml(fullPath);

        //        // Восстанавливаем прежние настройки
        //        gridView.OptionsLayout.StoreAppearance = storeAppearance;
        //        gridView.OptionsLayout.StoreDataSettings = storeDataSettings;
        //        gridView.FindFilterText = findFilterText;
        //        // Сохраняем текущие значения для восстановления
        //        var storeVisualOptions = gridView.OptionsLayout.StoreVisualOptions;
        //         storeAppearance = gridView.OptionsLayout.StoreAppearance;
        //         storeDataSettings = gridView.OptionsLayout.StoreDataSettings;

        //        // Оставляем только визуальные настройки столбцов (размеры, порядок, видимость)
        //        gridView.OptionsLayout.StoreVisualOptions = true;
        //        gridView.OptionsLayout.StoreAppearance = false;
        //        gridView.OptionsLayout.StoreDataSettings = false;

        //        gridView.SaveLayoutToXml(fullPath);

        //        // Восстанавливаем прежние настройки
        //        gridView.OptionsLayout.StoreVisualOptions = storeVisualOptions;
        //        gridView.OptionsLayout.StoreAppearance = storeAppearance;
        //        gridView.OptionsLayout.StoreDataSettings = storeDataSettings;
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogErrorAsync(ex, "Error saving grid view settings");
        //    }
        //}

        public void GridView_ColumnWidthChanged(object sender, ColumnEventArgs e)
        {
            if (sender is GridView view)
            {
                string fileName = $"{view.Name}Layout.xml";
                SaveGridViewSettings(view, fileName);
            }
        }

        //public void LoadGridViewSettings(GridView gridView, string fileName)
        //{
        //    try
        //    {
        //        string appPath = System.Windows.Forms.Application.StartupPath;
        //        string settingsPath = Path.Combine(appPath, "Settings");
        //        string fullPath = Path.Combine(settingsPath, fileName);

        //        if (!File.Exists(fullPath))
        //            return;

        //        using (XmlReader reader = XmlReader.Create(fullPath))
        //        {
        //            while (reader.Read())
        //            {
        //                if (reader.NodeType == XmlNodeType.Element && reader.Name == "Column")
        //                {
        //                    string fieldName = reader.GetAttribute("FieldName");
        //                    string widthStr = reader.GetAttribute("Width");
        //                    string visibleIndexStr = reader.GetAttribute("VisibleIndex");
        //                    string visibleStr = reader.GetAttribute("Visible");

        //                    if (int.TryParse(widthStr, out int width) && 
        //                        int.TryParse(visibleIndexStr, out int visibleIndex) &&
        //                        bool.TryParse(visibleStr, out bool visible))
        //                    {
        //                        GridColumn column = gridView.Columns[fieldName];
        //                        if (column != null)
        //                        {
        //                            column.Width = width;
        //                            column.VisibleIndex = visibleIndex;
        //                            column.Visible = visible;
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogErrorAsync(ex, "Error loading grid view settings");
        //    }
        //}

        public void SaveGridViewSettings(GridView gridView, string fileName)
        {
            try
            {
                string appPath = Application.StartupPath;
                string settingsPath = Path.Combine(appPath, "Settings");
                if (!Directory.Exists(settingsPath))
                    Directory.CreateDirectory(settingsPath);
                string fullPath = Path.Combine(settingsPath, fileName);
                List<XElement> columnElements = new List<XElement>();

                // Проходим по всем колонкам с помощью цикла
                for (int i = 0; i < gridView.Columns.Count; i++)
                {
                    GridColumn col = gridView.Columns[i];
                    if (!string.IsNullOrEmpty(col.FieldName))
                    {
                        columnElements.Add(
                            new XElement("Column",
                                new XAttribute("FieldName", col.FieldName),
                                new XAttribute("Width", col.Width),
                                new XAttribute("VisibleIndex", col.VisibleIndex),
                                new XAttribute("Visible", col.Visible),
                                new XAttribute("SortOrder", col.SortOrder.ToString()),
                                new XAttribute("SortIndex", col.SortIndex)
                                )
                        );
                    }
                }

                XElement columnsElement = new XElement("Columns", columnElements);
                // Формируем документ и сохраняем его в файл
                XDocument doc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), columnsElement);
                doc.Save(fullPath);
            }
            catch (Exception ex)
            {
                _logger.LogErrorAsync(ex, "Ошибка при сохранении настроек грида");
            }
        }

        public void LoadGridViewSettings(GridView gridView, string fileName)
        {
            if (gridView.GridControl.InvokeRequired)
            {
                gridView.GridControl.Invoke((MethodInvoker)(() =>
                {
                    LoadGridViewSettings(gridView, fileName);
                }));
                return;
            }

            try
            {
                string appPath = Application.StartupPath;
                string settingsPath = Path.Combine(appPath, "Settings");
                string fullPath = Path.Combine(settingsPath, fileName);

                if (!File.Exists(fullPath))
                    return;

                XDocument doc = XDocument.Load(fullPath);
                var columnElements = doc.Descendants("Column");

                foreach (var element in columnElements)
                {
                    string fieldName = element.Attribute("FieldName")?.Value;
                    if (string.IsNullOrEmpty(fieldName)) continue;

                    GridColumn column = gridView.Columns[fieldName];
                    if (column == null) continue;

                    if (int.TryParse(element.Attribute("Width")?.Value, out int width))
                        column.Width = width;

                    if (int.TryParse(element.Attribute("VisibleIndex")?.Value, out int visibleIndex))
                        column.VisibleIndex = visibleIndex;

                    if (bool.TryParse(element.Attribute("Visible")?.Value, out bool visible))
                        column.Visible = visible;

                    string sortOrderStr = element.Attribute("SortOrder")?.Value;
                    if (!string.IsNullOrEmpty(sortOrderStr) &&
                        Enum.TryParse<DevExpress.Data.ColumnSortOrder>(sortOrderStr, out var sortOrder))
                    {
                        column.SortOrder = sortOrder;
                    }

                    if (int.TryParse(element.Attribute("SortIndex")?.Value, out int sortIndex))
                        column.SortIndex = sortIndex;
                }
            }
            catch (Exception ex)
            {
                _logger.LogErrorAsync(ex, "Error loading grid view settings");
            }
        }


        //public void LoadGridViewSettings(GridView gridView, string fileName)
        //{
        //    try
        //    {
        //        string appPath = Application.StartupPath;
        //        string settingsPath = Path.Combine(appPath, "Settings");
        //        string fullPath = Path.Combine(settingsPath, fileName);

        //        if (!File.Exists(fullPath))
        //            return;

        //        XDocument doc = XDocument.Load(fullPath);
        //        var columnElements = doc.Descendants("Column");

        //        foreach (var element in columnElements)
        //        {
        //            string fieldName = element.Attribute("FieldName")?.Value;
        //            if (string.IsNullOrEmpty(fieldName))
        //                continue;

        //            GridColumn column = gridView.Columns[fieldName];
        //            if (column == null)
        //                continue;

        //            if (int.TryParse(element.Attribute("Width")?.Value, out int width))
        //                column.Width = width;

        //            if (int.TryParse(element.Attribute("VisibleIndex")?.Value, out int visibleIndex))
        //                column.VisibleIndex = visibleIndex;

        //            if (bool.TryParse(element.Attribute("Visible")?.Value, out bool visible))
        //                column.Visible = visible;
        //            string sortOrderStr = element.Attribute("SortOrder")?.Value;
        //            if (!string.IsNullOrEmpty(sortOrderStr))
        //            {
        //                if (Enum.TryParse<DevExpress.Data.ColumnSortOrder>(sortOrderStr, out var sortOrder))
        //                {
        //                    column.SortOrder = sortOrder;
        //                }
        //            }
        //            if (int.TryParse(element.Attribute("SortIndex")?.Value, out int sortIndex))
        //                column.SortIndex = sortIndex;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogErrorAsync(ex, "Error loading grid view settings");
        //    }
        //}

        #endregion

        #region sync
        /// <summary>
        /// Загружает данные в `GridControl` через `BindingSource`
        /// </summary>
        /// <param name="grid">GridControl, в который загружаются данные</param>
        /// <param name="source">BindingSource для привязки данных</param>
        /// <param name="data">DataTable с данными</param>
        public static void LoadGridControlData(GridControl grid, BindingSource source, DataTable data)
        {
            source.DataSource = data;
            grid.DataSource = source;
            grid.RefreshDataSource();
        }

        /// <summary>
        /// Применяет фильтр к `GridControl`
        /// </summary>
        /// <param name="grid">GridControl, который нужно отфильтровать</param>
        /// <param name="annId">Идентификатор разделения труда</param>
        public static void ApplyFilter(GridControl grid, int annId)
        {
            string filter = "annId = " + annId;
            GridView view = (GridView)grid.Views[0];
            view.BeginUpdate();
            view.ActiveFilterString = filter;
            view.EndUpdate();
        }

        /// <summary>
        /// Загружает изображение в `PictureBox` по `annId`
        /// </summary>
        /// <param name="pictureBox">PictureBox для загрузки изображения</param>
        /// <param name="data">DataTable с путем к изображению</param>
        public static void LoadImage(PictureBox pictureBox, DataTable data)
        {
            if (data != null && data.Rows.Count > 0)
            {
                pictureBox.ImageLocation = data.Rows[0]["pathpict"].ToString();
            }
        }

        /// <summary>
        /// Возвращает имя выбранного столбца для поиска
        /// </summary>
        /// <param name="kode">Радиокнопка "Код"</param>
        /// <param name="articul">Радиокнопка "Артикул"</param>
        /// <param name="model">Радиокнопка "Модель"</param>
        /// <param name="group">Радиокнопка "Группа"</param>
        /// <returns>Имя столбца для поиска</returns>
        public static string GetSelectedColumnName(bool kode, bool articul, bool model, bool group)
        {
            if (kode) return "kod";
            if (articul) return "articul";
            if (model) return "mod";
            if (group) return "grup";
            return string.Empty;
        }
        /// <summary>
        /// Проверяет, загружены ли данные в GridView
        /// </summary>
        /// <param name="view">GridView для проверки</param>
        /// <returns>True, если данные загружены</returns>
        public static bool IsDataTableLoaded(GridView view)
        {
            return view.DataSource is BindingSource bindingSource &&
                   bindingSource.DataSource is DataTable dataTable &&
                   dataTable.Rows.Count > 0;
        }

        /// <summary>
        /// Снимает выделение всех строк, кроме текущей
        /// </summary>
        /// <typeparam name="T">Тип данных (например, MyDataANN)</typeparam>
        /// <param name="gridView">GridView, в котором выполняется выделение</param>
        /// <param name="rowHandle">Индекс выбранной строки</param>
        public static void UpdateExclusiveCheck<T>(GridView gridView, int rowHandle) where T : class
        {
            var selectedData = gridView.GetRow(rowHandle) as T;
            if (selectedData is ICheckable checkableSelectedData)
            {
                checkableSelectedData.IsChecked = true;

                // Снимаем выделение с остальных строк
                for (int i = 0; i < gridView.RowCount; i++)
                {
                    if (i != rowHandle)
                    {
                        var otherData = gridView.GetRow(i) as T;
                        if (otherData is ICheckable checkableOtherData && checkableOtherData.IsChecked)
                        {
                            checkableOtherData.IsChecked = false;
                        }
                    }
                }
            }
            gridView.RefreshData();
        }
        #endregion

        public void popUpMenuCopy(object sender, DevExpress.XtraGrid.Views.Grid.PopupMenuShowingEventArgs e)
        {
            if (e.MenuType == GridMenuType.Row && e.HitInfo.Column != null)
            {
                var view = sender as GridView;
                // Копировать содержимое ячейки
                var copyCellItem = new DevExpress.Utils.Menu.DXMenuItem("Копировать", (_, __) =>
                {
                    int rowHandle = e.HitInfo.RowHandle;
                    var col = e.HitInfo.Column;
                    if (rowHandle >= 0 && col != null)
                    {
                        var cellText = view.GetRowCellDisplayText(rowHandle, col);
                        if (!string.IsNullOrEmpty(cellText))
                            Clipboard.SetText(cellText);
                    }
                });
                e.Menu.Items.Add(copyCellItem);
            }
        }

        #region LookUpHelper
        public void ConfigureComboBox(DevExpress.XtraEditors.LookUpEdit lookUpEdit, BindingSource bindingSource)
        {
            if (lookUpEdit != null && bindingSource != null)
            {
                lookUpEdit.Properties.DataSource = bindingSource;
                lookUpEdit.Properties.ValueMember = "Tab";
                lookUpEdit.Properties.DisplayMember = "Fio";
                lookUpEdit.Properties.Columns.Clear();
                lookUpEdit.Properties.Columns.Add(new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Fio", "ФИО"));
                lookUpEdit.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
                lookUpEdit.Properties.NullText = "[Выберите значение]";
            }
        }
        #endregion

        public static void sortGridView(GridView gridView)
        {
            if (gridView == null) return;

            gridView.BeginSort();
            try
            {
                gridView.ClearSorting(); // Очистить старую сортировку

                int sortIndex = 0; // Порядковый индекс сортировки

                // Если столбец "N" существует — сортируем
                var columnN = gridView.Columns.ColumnByFieldName("N");
                if (columnN != null)
                {
                    columnN.SortOrder = DevExpress.Data.ColumnSortOrder.Ascending;
                    columnN.SortIndex = sortIndex++;
                }

                // Если столбец "N1" существует — сортируем
                var columnN1 = gridView.Columns.ColumnByFieldName("N1");
                if (columnN1 != null)
                {
                    columnN1.SortOrder = DevExpress.Data.ColumnSortOrder.Ascending;
                    columnN1.SortIndex = sortIndex++;
                }

                // Если столбец "Kod_o" существует — сортируем
                var columnKodO = gridView.Columns.ColumnByFieldName("Kod_o");
                if (columnKodO != null)
                {
                    columnKodO.SortOrder = DevExpress.Data.ColumnSortOrder.Ascending;
                    columnKodO.SortIndex = sortIndex++;
                }
            }
            catch (Exception ex)
            {
                _logger.LogErrorAsync(ex, "Ошибка при сортировке таблицы");
            }
            finally
            {
                gridView.EndSort();
            }
        }

    }
}


