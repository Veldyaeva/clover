﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Views.Grid;
using SewingProduction.Extensions;
using SewingProduction.Features.TeamWork.Services;
using SewingProduction.Helpers;
using SewingProduction.Models;

namespace SewingProduction.Features.TeamWork.Helpers
{
    public class UIHelper
    {
        private readonly ILogger _logger;

        public UIHelper(ILogger logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Восстанавливает фокус на записи с указанным AnnID
        /// </summary>
        public async Task<bool> RestoreFocusAsync(GridView gridView, BindingList<ArtNormN> bindingList, int annId)
        {
            try
            {
                // Ищем строку с нужным AnnID
                int rowHandle = gridView.LocateByValue("AnnID", annId);

                if (rowHandle >= 0)
                {
                    gridView.BeginUpdate();
                    try
                    {
                        gridView.FocusedRowHandle = rowHandle;
                        gridView.MakeRowVisible(rowHandle);
                        gridView.RefreshRow(rowHandle);
                    }
                    finally
                    {
                        gridView.EndUpdate();
                    }

                    await _logger.LogEventAsync($"RestoreFocus: Фокус восстановлен на AnnID: {annId}, RowHandle: {rowHandle}", "TeamWorkUIHelper");
                    return true;
                }
                else
                {
                    await _logger.LogEventAsync($"RestoreFocus: Запись с AnnID: {annId} не найдена", "TeamWorkUIHelper");

                    // Если запись не найдена, устанавливаем фокус на первую доступную
                    if (bindingList.Count > 0)
                    {
                        gridView.FocusedRowHandle = 0;
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, $"Ошибка при восстановлении фокуса на AnnID: {annId}");
                return false;
            }
        }

        /// <summary>
        /// Обновляет UI с новыми связанными данными
        /// </summary>
        public async Task UpdateRelatedDataUIAsync(
            RelatedDataResult data,
            BindingList<NormRask> normRaskList,
            BindingList<NormKont> normKontList,
            BindingList<NormRasz> normRaszList,
            GridControl raszControl,
            GridControl raskrControl,
            GridControl kontControl,
            Control parentControl)
        {
            try
            {
                if (data == null || !data.Success)
                {
                    await _logger.LogEventAsync("UpdateRelatedDataUI: Переданы некорректные данные", "UIHelper");
                    return;
                }

                // Обновление данных должно происходить в UI потоке
                if (parentControl.InvokeRequired)
                {
                    await parentControl.InvokeAsync(() => UpdateRelatedDataSync(data, normRaskList, normKontList, normRaszList, raszControl, raskrControl, kontControl));
                }
                else
                {
                    UpdateRelatedDataSync(data, normRaskList, normKontList, normRaszList, raszControl, raskrControl, kontControl);
                }
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, "Ошибка при обновлении UI связанных данных");
            }
        }
        /// <summary>
        /// Применяет сортировку к связанным гридам
        /// </summary>
        private void ApplySortingToRelatedGrids(
            GridControl raszControl,
            GridControl raskrControl,
            GridControl kontControl)
        {
            try
            {
                if (raszControl?.MainView is GridView raszView)
                    TWGridHelper.sortGridView(raszView);
                if (raskrControl?.MainView is GridView raskrView)
                    TWGridHelper.sortGridView(raskrView);
                if (kontControl?.MainView is GridView kontView)
                    TWGridHelper.sortGridView(kontView);
            }
            catch (Exception ex)
            {
                _logger?.LogErrorAsync(ex, "Ошибка при применении сортировки к связанным гридам");
            }
        }

        private void UpdateRelatedDataSync(
            RelatedDataResult data,
            BindingList<NormRask> normRaskList,
            BindingList<NormKont> normKontList,
            BindingList<NormRasz> normRaszList,
            GridControl raszControl,
            GridControl raskrControl,
            GridControl kontControl)
        {
            try
            {
                if (normRaskList != null && data.NormRask != null)
                    normRaskList.BulkLoad(data.NormRask);

                if (normKontList != null && data.NormKont != null)
                    normKontList.BulkLoad(data.NormKont);

                if (normRaszList != null && data.NormRasz != null)
                    normRaszList.BulkLoad(data.NormRasz);

                // Применяем сортировку через отдельный метод
                ApplySortingToRelatedGrids(raszControl, raskrControl, kontControl);
            }
            catch (Exception ex)
            {
                _logger?.LogErrorAsync(ex, "Ошибка при синхронном обновлении UI");
            }
        }
        /// <summary>
        /// Применяет базовые настройки к гриду
        /// </summary>
        public async Task ResetGridToBaseStateAsync(GridView gridView, bool applyBaseSorting = true)
        {
            try
            {
                if (gridView == null) return;

                gridView.BeginUpdate();

                // Очищаем фильтры и сортировку
                gridView.ActiveFilter.Clear();
                gridView.ClearSorting();
                gridView.ClearGrouping();

                // Применяем базовые настройки
                gridView.OptionsView.ShowGroupPanel = false;
                gridView.OptionsView.ShowAutoFilterRow = true;
                gridView.OptionsView.EnableAppearanceEvenRow = true;
                gridView.OptionsView.EnableAppearanceOddRow = true;
                gridView.OptionsView.ShowIndicator = true;

                if (applyBaseSorting && gridView.Columns["dateCreate"] != null)
                {
                    gridView.Columns["dateCreate"].SortOrder = DevExpress.Data.ColumnSortOrder.Descending;
                }

                await _logger.LogEventAsync("Грид сброшен к базовому состоянию", "ResetGridToBaseState");
            }
            catch (Exception ex)
            {
                await _logger.LogErrorAsync(ex, "Ошибка при сбросе грида к базовому состоянию");
            }
            finally
            {
                gridView?.EndUpdate();
            }
        }

        /// <summary>
        /// Показывает сообщение о статусе операции
        /// </summary>
        public void ShowOperationStatus(Control parentControl, string message, int displayTimeMs = 3000)
        {
            try
            {
                if (parentControl is Form form)
                {
                    string originalTitle = form.Text;
                    form.Text = $"{originalTitle} - {message}";

                    // Восстанавливаем заголовок через указанное время
                    var timer = new System.Timers.Timer(displayTimeMs);
                    timer.Elapsed += (s, e) =>
                    {
                        timer.Stop();
                        timer.Dispose();

                        if (form.InvokeRequired)
                        {
                            form.Invoke(new Action(() => form.Text = originalTitle));
                        }
                        else
                        {
                            form.Text = originalTitle;
                        }
                    };
                    timer.Start();
                }
            }
            catch (Exception ex)
            {
                _logger?.LogErrorAsync(ex, "Ошибка при отображении статуса операции");
            }
        }

        // Универсальный безопасный апдейт для GridView
        public static void SafeUpdate(GridView gridView, Action updateAction)
        {
            if (gridView == null || updateAction == null) return;
            gridView.BeginDataUpdate();
            try { updateAction(); }
            finally { try { gridView.EndDataUpdate(); } catch { } }
        }

        // Обобщённая фабрика контекстного меню (удаление одной/нескольких строк + базовые пункты)
        public static PopupMenuShowingEventHandler CreateContextMenu<T>(GridView view, BindingList<T> bindingList, Func<T, int> getId, List<int> deletedIds)
            where T : class
        {
            return (s, e) =>
            {
                if (e.MenuType != GridMenuType.Row) return;
                var menu = e.Menu;

                // Удаление одной строки
                var deleteItem = new DevExpress.Utils.Menu.DXMenuItem("Удалить строку", (_, __) =>
                {
                    int rowHandle = e.HitInfo.RowHandle;
                    if (!view.IsValidRowHandle(rowHandle)) return;
                    var rowObj = view.GetRow(rowHandle) as T;
                    if (rowObj == null) return;

                    if (getId != null && deletedIds != null)
                    {
                        int id = getId(rowObj);
                        if (id > 0) deletedIds.Add(id);
                    }

                    bindingList.Remove(rowObj);
                });
                menu.Items.Add(deleteItem);

                // Массовое удаление по выделению
                var selectedRows = view.GetSelectedRows();
                if (selectedRows != null && selectedRows.Length > 0)
                {
                    var deleteSelectedItem = new DevExpress.Utils.Menu.DXMenuItem($"🗑 Удалить выбранные строки ({selectedRows.Length})", (_, __) =>
                    {
                        var toDelete = new List<T>();
                        foreach (var handle in selectedRows)
                        {
                            if (!view.IsValidRowHandle(handle)) continue;
                            var r = view.GetRow(handle) as T;
                            if (r != null) toDelete.Add(r);
                        }
                        SafeUpdate(view, () =>
                        {
                            foreach (var item in toDelete)
                            {
                                if (getId != null && deletedIds != null)
                                {
                                    int id = getId(item);
                                    if (id > 0) deletedIds.Add(id);
                                }
                                bindingList.Remove(item);
                            }
                        });
                    });
                    menu.Items.Add(deleteSelectedItem);
                }
            };
        }
    }
}

